/* eslint-disable */
import { AiOutlineCalendar, AiOutlineShoppingCart, AiOutlineAreaChart, AiOutlineBarChart, AiOutlineStock } from 'react-icons/ai';
import { FiShoppingBag, FiEdit, FiPieChart, FiBarChart, FiCreditCard, FiStar, FiShoppingCart } from 'react-icons/fi';
import { BsKanban, BsBarChart, BsBoxSeam, BsCurrencyDollar, BsShield, BsChatLeft } from 'react-icons/bs';
import { BiColorFill,BiChurch } from 'react-icons/bi';
import {FaBaby} from 'react-icons/fa';
import { IoMdContacts } from 'react-icons/io';
import { RiContactsLine, RiStockLine } from 'react-icons/ri';
import {GiHolyWater,GiHolyHandGrenade,GiLovers} from 'react-icons/gi'  
import {BsPeopleFill,BsCalendar4Event} from 'react-icons/bs'
import { MdOutlineSupervisorAccount } from 'react-icons/md';
import { HiOutlineRefresh } from 'react-icons/hi';
import { TiTick } from 'react-icons/ti';
import { GiLouvrePyramid } from 'react-icons/gi';
import { GrLocation } from 'react-icons/gr';
import avatar from './avatar.jpg';
import avatar2 from './avatar2.jpg';
import avatar3 from './avatar3.png';
import avatar4 from './avatar4.jpg';
import product1 from './product1.jpg';
import product2 from './product2.jpg';
import product3 from './product3.jpg';
import product4 from './product4.jpg';
import product5 from './product5.jpg';
import product6 from './product6.jpg';
import product7 from './product7.jpg';
import product8 from './product8.jpg';

export const gridOrderImage = (props) => (
  <div>
    <img
      className="rounded-xl h-20 md:ml-3"
      src={props.ProductImage}
      alt="order-item"
    />
  </div>
);

const gridEmployeeProfile = (props) => (
  <div className="flex items-center gap-2">
    <img
      className="rounded-full w-10 h-10"
      src={props.EmployeeImage}
      alt="employee"
    />
    <p>{props.Name}</p>
  </div>
);

const gridEmployeeCountry = (props) => (

  <div className="flex items-center justify-center gap-2">
    <GrLocation />
    <span>{props.Country}</span>
  </div>
);



export const gridOrderStatus = (props) => (
  <button
    type="button"
    style={{ background: props.StatusBg }}
    className="text-white py-1 px-2 capitalize rounded-2xl text-md"
  >
    {props.Status}
  </button>
);

export const links = [
    {
      title: 'Admin',
      links: [
        {
          name: 'members',
          // icon: <RiContactsLine />,
          icon: <BsPeopleFill/>
        },
        {
          name: 'baptism',
          // icon: <IoMdContacts />,
          icon: <FaBaby/>
        },
        {
          name: 'confirmation',
          // icon: <IoMdContacts />,
          icon: <BiChurch />
        },
        {
          name: 'marriage',
          // icon: <RiContactsLine />,
          icon: <GiLovers/>
          // GiHolyHandGrenade
        },
        {
          name: 'events',
          icon: <BsCalendar4Event />,
        }

      ],
    },
  ];

  export const linksStaff = [
    {
      title: 'Collegues',
      links: [
        {
          name: 'home',
          icon: <IoMdContacts />,
        },
        {
          name: 'planner',
          icon: <RiContactsLine />,
        },

      ],
    },
  ];

  export const chatData = [
    {
      image:
        avatar2,
      message: 'Roman Joined the Team!',
      desc: 'Congratulate him',
      time: '9:08 AM',
    },
    {
      image:
        avatar3,
      message: 'New message received',
      desc: 'Salma sent you new message',
      time: '11:56 AM',
    },
    {
      image:
        avatar4,
      message: 'New Payment received',
      desc: 'Check your earnings',
      time: '4:39 AM',
    },
    {
      image:
        avatar,
      message: 'Jolly completed tasks',
      desc: 'Assign her new tasks',
      time: '1:12 AM',
    },
  ];

  export const themeColors = [
    {
      name: 'blue-theme',
      color: '#1A97F5',
    },
    {
      name: 'green-theme',
      color: '#03C9D7',
    },
    {
      name: 'purple-theme',
      color: '#7352FF',
    },
    {
      name: 'red-theme',
      color: '#FF5C8E',
    },
    {
      name: 'indigo-theme',
      color: '#1E4DB7',
    },
    {
      color: '#FB9678',
      name: 'orange-theme',
    },
  ];

  export const ordersData = [
    {
      FullName: 'Aron',
      Surname: "Benjamin",
      FathersName: 'Erik',
      FatherSurname: 'Iiyambo',
      MothersName:"Sirka",
      MotherSurname:"Hamutenya"
    },
    {
      FullName: 'Aron',
      Surname: "Benjamin",
      FathersName: 'Erik',
      FatherSurname: 'Iiyambo',
      MothersName:"Sirka",
      MotherSurname:"Hamutenya"
    },
    {
      FullName: 'Aron',
      Surname: "Benjamin",
      FathersName: 'Erik',
      FatherSurname: 'Iiyambo',
      MothersName:"Sirka",
      MotherSurname:"Hamutenya"
    },
    {
      FullName: 'Aron',
      Surname: "Benjamin",
      FathersName: 'Erik',
      FatherSurname: 'Iiyambo',
      MothersName:"Sirka",
      MotherSurname:"Hamutenya"
    },
    {
      FullName: 'Aron',
      Surname: "Benjamin",
      FathersName: 'Erik',
      FatherSurname: 'Iiyambo',
      MothersName:"Sirka",
      MotherSurname:"Hamutenya"
    },
    {
      FullName: 'Aron',
      Surname: "Benjamin",
      FathersName: 'Erik',
      FatherSurname: 'Iiyambo',
      MothersName:"Sirka",
      MotherSurname:"Hamutenya"
    },
    {
      FullName: 'Aron',
      Surname: "Benjamin",
      FathersName: 'Erik',
      FatherSurname: 'Iiyambo',
      MothersName:"Sirka",
      MotherSurname:"Hamutenya"
    },
    {
      FullName: 'Aron',
      Surname: "Benjamin",
      FathersName: 'Erik',
      FatherSurname: 'Iiyambo',
      MothersName:"Sirka",
      MotherSurname:"Hamutenya"
    },
    {
      FullName: 'Aron',
      Surname: "Benjamin",
      FathersName: 'Erik',
      FatherSurname: 'Iiyambo',
      MothersName:"Sirka",
      MotherSurname:"Hamutenya"
    },
    {
      FullName: 'Aron',
      Surname: "Benjamin",
      FathersName: 'Erik',
      FatherSurname: 'Iiyambo',
      MothersName:"Sirka",
      MotherSurname:"Hamutenya"
    },
    {
      FullName: 'Aron',
      Surname: "Benjamin",
      FathersName: 'Erik',
      FatherSurname: 'Iiyambo',
      MothersName:"Sirka",
      MotherSurname:"Hamutenya"
    },

];

export const confirmationColumns = [
  {
    field: 'name',
    headerText: 'FullName',
    width: '50',
    editType: 'dropdownedit',
    textAlign: 'Center',
  },
  { field: 'surname',
    headerText: 'Surname',
    width: '50',
    textAlign: 'Center',
  },
  {
    field: "dateOfConfirmation",
    headerText: "confirmation date",
    format: 'C2',
    textAlign: 'Center',
    editType: 'numericedit',
    width: '50',
  },
  {
    field: 'placeOfConfirmation',
    headerText: "Confirmation Place",
    format: 'C2',
    textAlign: 'Center',
    editType: 'numericedit',
    width: '50',
  }

];

export const ordersGrid = [
  {
    field: 'name',
    headerText: 'FullName',
    width: '50',
    editType: 'dropdownedit',
    textAlign: 'Center',
  },
  { field: 'surname',
    headerText: 'Surname',
    width: '50',
    textAlign: 'Center',
  },
  {
    field: "fatherName",
    headerText: "father's Name",
    format: 'C2',
    textAlign: 'Center',
    editType: 'numericedit',
    width: '50',
  },
  {
    field: "fatherSurname",
    headerText: "father's Surname",
    format: 'C2',
    textAlign: 'Center',
    editType: 'numericedit',
    width: '50',
  },
  {
    field: 'motherName',
    headerText: "Mother's Name",
    format: 'C2',
    textAlign: 'Center',
    editType: 'numericedit',
    width: '50',
  },
  {
    field: 'motherSurname',
    headerText: "Mother's Surname",
    format: 'C2',
    textAlign: 'Center',
    editType: 'numericedit',
    width: '50',
  },
];

export const baptismColumns = [
  {
    field: 'name',
    headerText: 'FullName',
    width: '50',
    editType: 'dropdownedit',
    textAlign: 'Center',
  },
  { field: 'surname',
    headerText: 'Surname',
    width: '50',
    textAlign: 'Center',
  },
  {
    field: "placeOfBaptism",
    headerText: "Baptism Place",
    format: 'C2',
    textAlign: 'Center',
    editType: 'numericedit',
    width: '50',
  },
  {
    field: "dateOfBaptism",
    headerText: "Baptism Date",
    format: 'C2',
    textAlign: 'Center',
    editType: 'numericedit',
    width: '50',
  },
  // {
  //   field: 'motherName',
  //   headerText: "Mother's Name",
  //   format: 'C2',
  //   textAlign: 'Center',
  //   editType: 'numericedit',
  //   width: '50',
  // },
  // {
  //   field: 'motherSurname',
  //   headerText: "Mother's Surname",
  //   format: 'C2',
  //   textAlign: 'Center',
  //   editType: 'numericedit',
  //   width: '50',
  // },
];

export const marriageColumns = [
  {
    field: 'name',
    headerText: 'FullName',
    width: '50',
    editType: 'dropdownedit',
    textAlign: 'Center',
  },
  { field: 'surname',
    headerText: 'Surname',
    width: '50',
    textAlign: 'Center',
  },
  {
    field: "spouseName",
    headerText: "Spouse Name",
    format: 'C2',
    textAlign: 'Center',
    editType: 'numericedit',
    width: '50',
  },
  {
    field: "spouseSurname",
    headerText: "Spouse Surname",
    format: 'C2',
    textAlign: 'Center',
    editType: 'numericedit',
    width: '50',
  },
];

export const earningData = [
  {
    icon: <MdOutlineSupervisorAccount />,
    title: 'Signed in',
    iconColor: '#03C9D7',
    iconBg: '#E5FAFB',
    pcColor: 'red-600',
  },
  {
    icon: <BsBoxSeam />,
    title: 'Signed off',
    iconColor: 'rgb(255, 244, 229)',
    iconBg: 'rgb(254, 201, 15)',
    pcColor: 'green-600',
  },
  {
    icon: <RiStockLine/>,
    title: 'Save',
    iconColor: 'rgb(255, 244, 229)',
    iconBg: 'rgb(254, 201, 15)',
    pcColor: 'green-600',
  }
];

///
export let data1 = [
  { x: 'Monday', y: 17 },
  { x: 'Tuesday', y: 17.10 },
  { x: 'Wednesday', y: 17 },
  { x: 'Thursday', y: 18 },
  { x: 'Friday', y: 17 },
];
export let data2 = [
  { x: 'Monday', y: 8 },
  { x: 'Tuesday', y: 8.30 },
  { x: 'Wednesday', y: 9 },
  { x: 'Thursday', y: 8.10 },
  { x: 'Friday', y: 7.55 },
];


export const employeesData = [
  {
    EmployeeID: 1,
    FullName: 'Erikson',
    Surname: "Abraham",
    FatherSurname: 'Erick',
    FathersName :'Tate',
    MothersName:"Hamnunya",
    MotherSurname:"Sirka"
  
  },
  {
    EmployeeID: 1,
    Name: 'Abraham Erikson',
    signedIn: '08:10',
    signedOut: '17:00',
    Status: 'Approved',
    EmployeeImage:
    avatar3,
  },
  {
    EmployeeID: 1,
    Name: 'Abraham Erikson',
    signedIn: '08:10',
    signedOut: '17:00',
    Status: 'Approved',
    EmployeeImage:
    avatar3,
  },
  {
    EmployeeID: 1,
    Name: 'Abraham Erikson',
    signedIn: '08:10',
    signedOut: '17:00',
    Status: 'Approved',
    EmployeeImage:
    avatar3,
  },
  {
    EmployeeID: 1,
    Name: 'Abraham Erikson',
    signedIn: '08:10',
    signedOut: '17:00',
    Status: 'Approved',
    EmployeeImage:
    avatar3,
  },
  {
    EmployeeID: 1,
    Name: 'Abraham Erikson',
    signedIn: '08:10',
    signedOut: '17:00',
    Status: 'Approved',
    EmployeeImage:
    avatar3,
  },
  {
    EmployeeID: 1,
    Name: 'Abraham Erikson',
    signedIn: '08:10',
    signedOut: '17:00',
    Status: 'Approved',
    EmployeeImage:
    avatar3,
  }
];

export const employeesGrid = [

  { field: 'FullName',
    headerText: 'Full Names',
    width: '170',
    textAlign: 'Center',
  },
  { field: 'Surname',
    headerText: 'Surname',
    width: '170',
    textAlign: 'Center',
  },
  { field: "FathersNames",
    headerText: "Father's Names",
    width: '120',
    textAlign: 'Center',
 },

  { field: "FatherSurname",
    headerText: 'FatherSurname',
    width: '135',
    textAlign: 'Center' },
  { field: "MothersName",
    headerText: "MothersName",
    width: '125',
    textAlign: 'Center' },
    { field: "MotherSurname",
    headerText: "MotherSurname",
    width: '125',
    textAlign: 'Center' },
];


export const scheduleData = [
  {
    Id: 1,
    Subject: 'Explosion of Betelgeuse Star',
    Location: 'Space Center USA',
    StartTime: '2021-01-10T04:00:00.000Z',
    EndTime: '2021-01-10T05:30:00.000Z',
    CategoryColor: '#1aaa55',
  },
  {
    Id: 2,
    Subject: 'Thule Air Crash Report',
    Location: 'Newyork City',
    StartTime: '2021-01-11T06:30:00.000Z',
    EndTime: '2021-01-11T08:30:00.000Z',
    CategoryColor: '#357cd2',
  },
  {
    Id: 3,
    Subject: 'Blue Moon Eclipse',
    Location: 'Space Center USA',
    StartTime: '2021-01-12T04:00:00.000Z',
    EndTime: '2021-01-12T05:30:00.000Z',
    CategoryColor: '#7fa900',
  },
  {
    Id: 4,
    Subject: 'Meteor Showers in 2021',
    Location: 'Space Center USA',
    StartTime: '2021-01-13T07:30:00.000Z',
    EndTime: '2021-01-13T09:00:00.000Z',
    CategoryColor: '#ea7a57',
  },
  {
    Id: 5,
    Subject: 'Milky Way as Melting pot',
    Location: 'Space Center USA',
    StartTime: '2021-01-14T06:30:00.000Z',
    EndTime: '2021-01-14T08:30:00.000Z',
    CategoryColor: '#00bdae',
  },
  {
    Id: 6,
    Subject: 'Mysteries of Bermuda Triangle',
    Location: 'Bermuda',
    StartTime: '2021-01-14T04:00:00.000Z',
    EndTime: '2021-01-14T05:30:00.000Z',
    CategoryColor: '#f57f17',
  },
  {
    Id: 7,
    Subject: 'Glaciers and Snowflakes',
    Location: 'Himalayas',
    StartTime: '2021-01-15T05:30:00.000Z',
    EndTime: '2021-01-15T07:00:00.000Z',
    CategoryColor: '#1aaa55',
  },
  {
    Id: 8,
    Subject: 'Life on Mars',
    Location: 'Space Center USA',
    StartTime: '2021-01-16T03:30:00.000Z',
    EndTime: '2021-01-16T04:30:00.000Z',
    CategoryColor: '#357cd2',
  },
  {
    Id: 9,
    Subject: 'Alien Civilization',
    Location: 'Space Center USA',
    StartTime: '2021-01-18T05:30:00.000Z',
    EndTime: '2021-01-18T07:30:00.000Z',
    CategoryColor: '#7fa900',
  },
  {
    Id: 10,
    Subject: 'Wildlife Galleries',
    Location: 'Africa',
    StartTime: '2021-01-20T05:30:00.000Z',
    EndTime: '2021-01-20T07:30:00.000Z',
    CategoryColor: '#ea7a57',
  },
  {
    Id: 11,
    Subject: 'Best Photography 2021',
    Location: 'London',
    StartTime: '2021-01-21T04:00:00.000Z',
    EndTime: '2021-01-21T05:30:00.000Z',
    CategoryColor: '#00bdae',
  },
  {
    Id: 12,
    Subject: 'Smarter Puppies',
    Location: 'Sweden',
    StartTime: '2021-01-08T04:30:00.000Z',
    EndTime: '2021-01-08T06:00:00.000Z',
    CategoryColor: '#f57f17',
  },
  {
    Id: 13,
    Subject: 'Myths of Andromeda Galaxy',
    Location: 'Space Center USA',
    StartTime: '2021-01-06T05:00:00.000Z',
    EndTime: '2021-01-06T07:00:00.000Z',
    CategoryColor: '#1aaa55',
  },
  {
    Id: 14,
    Subject: 'Aliens vs Humans',
    Location: 'Research Center of USA',
    StartTime: '2021-01-05T04:30:00.000Z',
    EndTime: '2021-01-05T06:00:00.000Z',
    CategoryColor: '#357cd2',
  },
  {
    Id: 15,
    Subject: 'Facts of Humming Birds',
    Location: 'California',
    StartTime: '2021-01-19T04:00:00.000Z',
    EndTime: '2021-01-19T05:30:00.000Z',
    CategoryColor: '#7fa900',
  },
  {
    Id: 16,
    Subject: 'Sky Gazers',
    Location: 'Alaska',
    StartTime: '2021-01-22T05:30:00.000Z',
    EndTime: '2021-01-22T07:30:00.000Z',
    CategoryColor: '#ea7a57',
  },
  {
    Id: 17,
    Subject: 'The Cycle of Seasons',
    Location: 'Research Center of USA',
    StartTime: '2021-01-11T00:00:00.000Z',
    EndTime: '2021-01-11T02:00:00.000Z',
    CategoryColor: '#00bdae',
  },
  {
    Id: 18,
    Subject: 'Space Galaxies and Planets',
    Location: 'Space Center USA',
    StartTime: '2021-01-11T11:30:00.000Z',
    EndTime: '2021-01-11T13:00:00.000Z',
    CategoryColor: '#f57f17',
  },
  {
    Id: 19,
    Subject: 'Lifecycle of Bumblebee',
    Location: 'San Fransisco',
    StartTime: '2021-01-14T00:30:00.000Z',
    EndTime: '2021-01-14T02:00:00.000Z',
    CategoryColor: '#7fa900',
  },
  {
    Id: 20,
    Subject: 'Alien Civilization',
    Location: 'Space Center USA',
    StartTime: '2021-01-14T10:30:00.000Z',
    EndTime: '2021-01-14T12:30:00.000Z',
    CategoryColor: '#ea7a57',
  },
  {
    Id: 21,
    Subject: 'Alien Civilization',
    Location: 'Space Center USA',
    StartTime: '2021-01-10T08:30:00.000Z',
    EndTime: '2021-01-10T10:30:00.000Z',
    CategoryColor: '#ea7a57',
  },
  {
    Id: 22,
    Subject: 'The Cycle of Seasons',
    Location: 'Research Center of USA',
    StartTime: '2021-01-12T09:00:00.000Z',
    EndTime: '2021-01-12T10:30:00.000Z',
    CategoryColor: '#00bdae',
  },
  {
    Id: 23,
    Subject: 'Sky Gazers',
    Location: 'Greenland',
    StartTime: '2021-01-15T09:00:00.000Z',
    EndTime: '2021-01-15T10:30:00.000Z',
    CategoryColor: '#ea7a57',
  },
  {
    Id: 24,
    Subject: 'Facts of Humming Birds',
    Location: 'California',
    StartTime: '2021-01-16T07:00:00.000Z',
    EndTime: '2021-01-16T09:00:00.000Z',
    CategoryColor: '#7fa900',
  },
];
