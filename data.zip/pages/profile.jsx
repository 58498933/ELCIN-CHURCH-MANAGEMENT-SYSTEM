
import React,{useState,useEffect} from 'react'
import { FiEdit } from 'react-icons/fi';
import trees from "C:/Users/Erick Abraham/Documents/Eacelab/Cms/client/src/assets/trees.jpg"

import Baptism from "../Components/AllTabs/baptism";
import Confirmation from "../Components/AllTabs/confirmation";
import Marriage from "../Components/AllTabs/marriage";
import { useNavigate } from 'react-router-dom';
import { useLocation } from 'react-router-dom';
import Transaction from "../Components/Transaction"
import UserDetails from '../Components/UserDetails';
import axios from "axios";
import { IoIosAddCircleOutline } from 'react-icons/io';
import { BsArrowLeft } from 'react-icons/bs';



// Profile should receive the obj of the clicked table record
// Given the UserID number
// Query the Baptism,Confirmation,Marriage database to show the info




const Profile = () => {
  var location = useLocation()

  var userData = location.state.memberData;
  const [baptism,setBaptism] = useState({})
  const [confirmation,setConfirmation] = useState({});
  const [marriage,setMarriage] = useState({})
  const [payments,setPayments] = useState([])


  console.log("Printing the userData in /Profile");
  console.log(userData);
  var navigate = useNavigate();

  useEffect( () =>{
    const response = axios.get(`http://localhost:3000/baptism/${userData.idNumber}`).then((res) =>{

    if(res.data.length > 0){
      console.log("PRINTING THE BAPTISM DATA")
      var data = res.data[0];
      console.log(data);
      setBaptism(data);
    }else{
      console.log("We did not get the data from db")
    }
    }).catch( (error) =>{
      console.log(`An error has occured ${error}`);
    })

    const confirmationData = axios.get(`http://localhost:3000/confirmation/${userData.idNumber}`).then( (res) =>{

      if(res.data.length > 0){
        console.log("WE GOT THE CONFIRMATION DATA")
        console.log(res.data);
        var data = res.data[0];
        setConfirmation(data);
      }else{
        console.log("We did not get any confirmation record from the db")
      }

    });

    const marriageData = axios.get(`http://localhost:3000/marriage/${userData.idNumber}`).then( (res) =>{   
      if(res.data.length > 0){
          console.log("We got the marriage data from database -*************************************")
          console.log(res.data)
          var data = res.data[0]
          setMarriage(data)
        }else{
          console.log("We did not get marriage data from the db");
        }
    }).catch( (error) =>{
      console.log(error);
    });

    const transaction = axios.get(`http://localhost:3000/payments/${userData.idNumber}`).then( (res) =>{
      if(res.data.length > 0){
        console.log("We got the transactions data from db");
        console.log(res.data);
        setPayments(res.data);
      }else{
        console.log("We did not get any payments from the db")
      }
    }).catch( (error) => {
      console.log(`We got an error from db ${error}`)
    })

  },[userData])


  const newTransaction = () =>{
    navigate("/new_transaction",{state:{userData:userData}})
  }


  const nav = () => {
    navigate("/edit_profile",{state:{userData:userData}});
  }

  const navBack = () => {
    navigate(-1)
  }
const [activeTab,setActivetab] = useState("Baptism");

  // method for handling switch functionality
  const handleBaptism = () => {
    setActivetab("Baptism");
  }
  // method for handling admin switch functionality
  const handleConfirmation = () => {
    setActivetab("Confirmation");
  }

  const handleMarriage = () => {
    setActivetab("Marriage");
  }

  return (
    <div className=''>
  <div className='m-10'>
      <div className='h-3/4 ' >
        <div className='rounded-md m-1 mt-5 h-2/4 w-2/4 border-2'>
        
          <div className=' float-right m-2'>
              <button type='button' onClick={nav}  style={{ color:'#03C9D7',backgroundColor:'#e5fafb'}} className="text-2xl opacity-0.9 p-4 hover:drop-shadow-xl rounded-lg">
                <FiEdit />
              </button>
              <p className=' m-1 text-white'>Edit</p>
          </div>
        <UserDetails lifeStatus={userData.status} FullName={userData.name + " " + userData.surname} dob={userData.dateOfBirth} idNumber={userData.idNumber} fatherFullName={userData.fatherName} motherFullName={userData.motherName}/>
        </div>
      </div>

       <h2 className='text-center font-bold text-xl mt-3 text-white '>More Information</h2>

    <div className="Tabs mt-0 border-2">
      {/* Tab nav */}
      <ul className="nav ">
        <li className={activeTab === "Baptism" ? "active":""} onClick={handleBaptism}>Baptism
        </li>
        <li className={activeTab === "Confirmation" ? "active":""} onClick={handleConfirmation}>Confirmation</li>
        <li className={activeTab === "Marriage" ? "active":""} onClick={handleMarriage}>Marriage</li>
      </ul>
      <div className="outlet">
        {/* content will be shown here */}
        {/* {(activeTab === "Baptism" && baptism.length > 0 ) ? <Baptism admin={true} userData={userData} baptismData={baptism}/> : <></> } */}
        {(activeTab === "Baptism") ? ( Object.keys(baptism).length > 0 ? <Baptism admin={true} userData={userData} baptismData={baptism}/>: <p className=' text-center font-bold text-xl'> {userData.name + " " + userData.surname} is not yet Baptised !</p>) : <></> }
        {activeTab === "Confirmation" ? (Object.keys(confirmation).length > 0 ? <Confirmation admin={true} userData={userData} confirmationData={confirmation} /> : <p className=' text-center font-bold text-xl'> {userData.name + " " + userData.surname} is not yet Confirmed !</p>) : <></>}
        {activeTab === "Marriage" ? (Object.keys(marriage).length > 0 ? <Marriage admin={true} userData={userData}  marriageData={marriage} /> : <p className=' text-center font-bold text-xl'> {userData.name + " " + userData.surname} is not yet Married !</p>) : <></>}
      </div>
    </div>

    {/* Div for showing transaction history */}

      <div className=' '> 
      <h1 className=' text-center font-bold text-xl text-white'>Transactions</h1> 
      <button type='button' onClick={newTransaction}  style={{ color:'#03C9D7',backgroundColor:'#e5fafb'}} className=" rounded opacity-0.9 p-2 hover:drop-shadow-xl">
         <IoIosAddCircleOutline />
         <p className=' font-bold'>Add new</p>
        </button>
      </div>

   

    {(payments.length > 0) ? (payments.map( (pay) =>{
      return <Transaction amountPayed={pay.amountPayed} date={pay.date} reference={pay.reference} outstanding={""}/>
    }) ) : <h1 className=' text-center font-bold text-xl text-white'>There are not transactions yet!</h1>}



    {/* <Transaction amountPayed={5000} date={"5 May 2022"} reference={"Baptism"} outstanding={600}/> */}

    </div>
    </div>
  )
}

export default Profile