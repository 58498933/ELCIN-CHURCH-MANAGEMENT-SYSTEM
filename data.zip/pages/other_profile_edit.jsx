import React from 'react'
import { useLocation } from 'react-router-dom';

import EditBaptism from "../Components/EditBaptism"
import EditConfirmation from '../Components/EditConfirmation';
import EditMarriage from '../Components/EditMarriage';




const Other_profile_edit = () => {
  
  var location = useLocation();
  console.log(location.state.type)

  const type = location.state.type;
  const userData = location.state.userData;
  const marriageData = location.state.marriageData;

  if(type === "Baptism"){
    return (
     <EditBaptism userData={userData}/>
    );
  }else if(type === "Confirmation"){
    return (
      <EditConfirmation userData={userData}/>
    );
  }else {
    return (
    <EditMarriage userData={userData} marriageData={marriageData}/>
    );
  }

}

export default Other_profile_edit