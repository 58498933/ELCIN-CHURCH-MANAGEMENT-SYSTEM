import React, { useEffect ,useState} from 'react'
import  {useNavigate  } from 'react-router-dom'
import { ColumnDirective, ColumnsDirective, GridComponent,Grid } from '@syncfusion/ej2-react-grids';
import { ordersData, contextMenuItems, marriageColumns } from '../data/dummy';
import Header from "../Components/Header"
import { Inject, Search, Toolbar } from '@syncfusion/ej2-react-grids';
import { IoIosAddCircleOutline } from 'react-icons/io';
import axios from "axios"



const Marriage = () => {
  var navigate = useNavigate();

  const [marriageData,setMarriageData] = useState([]);
  const [membersData,setMembersData] = useState([]);
  const [finalData,setFinalData] = useState([]);

  useEffect( () =>{
    console.log("LISTENING TO THE MEMBERSDATA NOW")
    processData();
   },[membersData])

  useEffect( () =>{

    async function getData() {

      const marriage = await axios.get("http://localhost:3000/joinMarriage").then( (res) => {
        if(res.data.length > 0){
            console.log("Then we have gotten the marriage data")
            console.log(res.data)
            setMarriageData(res.data);
        }
    
    
    
      }).catch((error) => {
      console.log(error)
    })
  
    const member = await axios.get("http://localhost:3000/members").then( (res) => {
      if(res.data.length > 0){
          console.log("Then we have gotten the MEMBERS data")
          console.log(res.data)
          setMembersData(res.data);
      }
  
    }).catch((error) => {
    console.log(error)
  })

    }

    getData();


  
  
   },[])

  const rowSelected = (grid) => {
  
   console.log(grid);
   var memberData = {};
     if (grid) {

      var id = grid.data.idNumber;

      membersData.forEach(element => {
          if(element.idNumber === id){
            memberData = element;
          }
      });

       navigate("/profile",{state:{memberData:memberData}});
       console.log(grid.data);
     }   
 }

  const processData = () => {

    console.log("We are in the process data methody");

    var data  = {}
    if(membersData.length > 0 && marriageData.length > 0){
      console.log("The condition is true , we can add to the final data");
      
      //   field: 'name',
      //  field: 'surname',
      //   field: "dateOfConfirmation",
      //   field: 'placeOfConfirmation',

      marriageData.forEach(e => {

        membersData.forEach(member => {

            if(e.idNumber === member.idNumber){
              console.log("We found a matching record")

              // "spouseName": "Niks",
              // "spouseSurname": "Elenga",


              data.name = member.name;
              data.surname = member.surname;
              data.spouseName = e.spouseName;
              data.spouseSurname = e.spouseSurname;
              data.idNumber = e.idNumber;

              // Checking if the data is already in list
              if(finalData.includes(data)){
                console.log(" DATA IS ALREADY IN THE LIST")
              }else{
                console.log("WE CAN ADD THE FINAL LIST")
                setFinalData( prev => [...prev,data])
              }
              
            }
        });

      });
      
    }

  }

 const nav = () =>{
  navigate("/new_record",{state:{type:"Married",}})
}

 return (
   <div className="m-2 md:m-10 p-2 md:p-10 bg-white rounded-3xl">
    {/* <Header title={"Baptism book"}/> */}
    <div>
      <p className='float-left text-3xl font-extrabold tracking-tight text-slate-900'>Marriage Book</p>
      <button type='button' onClick={nav}  style={{ color:'#03C9D7',backgroundColor:'#E5FAFB'}} className="rounded-3xl opacity-0.9 p-2 hover:drop-shadow-xl float-right">
       <IoIosAddCircleOutline />
      </button>
    </div>
 

    <div className='mt-10'>
    <GridComponent
     id='gridcomp'
     dataSource={marriageData}
     toolbar={["Search"]}
     allowSorting
     allowPaging
      rowSelected={rowSelected} 
    >

       <ColumnsDirective>
         {marriageColumns.map((item,index,) => (
           <ColumnDirective key={index} {...item}/>
         ))}
       </ColumnsDirective>
       <Inject services={[Search, Toolbar]}/>
     </GridComponent>
    </div>
  

   </div>
 )
}

export default Marriage
