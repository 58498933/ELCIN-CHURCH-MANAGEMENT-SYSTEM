import React,{useEffect, useState} from 'react'
import { FiEdit } from 'react-icons/fi';
import trees from "C:/Users/Erick Abraham/Documents/Eacelab/Cms/client/src/assets/trees.jpg"

import Baptism from "../Components/AllTabs/baptism";
import Confirmation from "../Components/AllTabs/confirmation";
import Marriage from "../Components/AllTabs/marriage";
import { useNavigate } from 'react-router-dom';
import { useLocation } from 'react-router-dom';
import Transaction from '../Components/Transaction';
import axios from "axios"
import Event from '../Components/event';

const Member = () => {
  
  var navigate = useNavigate();
  var location = useLocation();
  const [baptism,setBaptism] = useState({});
  const [confirmation,setConfirmation] = useState({});
  const [marriage,setMarriage] = useState({});
  const [payments,setPayments] = useState([]);
  const [events,setEvents] = useState([]);

  var userData = location.state.userData[0];

  console.log("Printing the received DATA in MEMBERS PAGE");
  console.log(userData);

  useEffect(() => {
    const response = axios.get(`http://localhost:3000/baptism/${userData.idNumber}`).then( (res) => {

    if(res.data.length > 0){
      console.log("We got something from the database");
      console.log(res.data);
      var data = res.data[0];
      setBaptism(data)

    }else{
      console.log("AN ERROR has Occured, we did not get anyrhing from the DB");
    }

    }).catch( (error) => {
      console.log(error)
    })

    const confirmationData = axios.get(`http://localhost:3000/confirmation/${userData.idNumber}`).then( (res)=>{
      if(res.data.length > 0){

        console.log("We got something from the database");
        console.log(res.data);
        var data = res.data[0];
        setConfirmation(data)

      }else{
        console.log("We did not get the data from db")
      }
    }).catch( (error) =>{
      console.log(error);
    })

    const marriageData = axios.get(`http://localhost:3000/marriage/${userData.idNumber}`).then( (res) =>{
      if(res.data.length > 0){
        console.log("We got something from the database");
        console.log(res.data);
        var data = res.data[0];
        setMarriage(data)
      }else{
        console.log("An error has occurred! ")
      }
    })

    const paymentData = axios.get(`http://localhost:3000/payments/${userData.idNumber}`).then((res) =>{
      if(res.data.length > 0){
        console.log("We got something from the database for   PAYMENTS");
        console.log(res.data);
        var data = res.data;

        data.forEach(element => {
          
          if(payments.includes(element)){
            console.log("The obj is already in the payments list")
            
          }else{
            // If the payments does not include the new obj from database, then we can add
            setPayments(prev => [...prev,element]);
            console.log("Printing the payments array");
            console.log(payments);
          }
         
        });
 

      }else{
        console.log("An error has occurred! ")
      }
    })

    const events = axios.get('http://localhost:3000/events').then((res) =>{
      if(res.data.length > 0){
        console.log("We got something from the database for  EVENTS");
        console.log(res.data);
        var data = res.data;
          setEvents(data)
 
      }else{
        console.log("An error has occurred! ")
      }
    })

  },[userData])

  const nav = () => {
    navigate("/edit_profile")
  }

const [activeTab,setActivetab] = useState("Baptism");

  // method for handling switch functionality
  const handleBaptism = () => {
    setActivetab("Baptism");
  }
  // method for handling admin switch functionality
  const handleConfirmation = () => {
    setActivetab("Confirmation");
  }

  const handleMarriage = () => {
    setActivetab("Marriage");
  }

  return (
  <div>
    <div className='m-10 rounded '>
      <div className='h-3/4 ml-24' >
          <div className='m-1 mt-5 h-2/4 w-2/4 rounded-md border-2'>
        
            <div className=' m-2 text-white'>
              <h3 className=' font-bold text-xl mt-2'><span className=' font-extrabold text-2xl'>Full Name: </span>{userData.name + " " + userData.surname}</h3>
              <h3 className=' text-xl font-semibold mt-2'> <span className='font-extrabold text-2xl'>D.O.B:  </span>{userData.dateOfBirth}</h3>
              <h3 className=' text-xl font-semibold mt-2'> <span className=' font-extrabold text-2xl'>ID:  </span>{userData.idNumber}</h3>
              <h3 className=' text-xl font-semibold mt-2'> <span className='font-extrabold text-2xl'>Father's Name: </span>{userData.fatherName +" " +userData.fatherSurname}</h3>
              <h3 className=' text-xl font-semibold mt-2'> <span className=' font-extrabold text-2xl'>Mother's Name: </span>{userData.motherName +" " + userData.motherSurname}</h3>
            </div>

          </div>
          {/* MOVE CODE HERE */}

        <h2 className='text-center font-bold text-xl text-white '>More Info</h2>

        <div className="Tabs mt-0 border-2">
              {/* Tab nav */}
            <ul className="nav ">
              <li className={activeTab === "Baptism" ? "active":""} onClick={handleBaptism}>Baptism
              
              </li>
              <li className={activeTab === "Confirmation" ? "active":""} onClick={handleConfirmation}>Confirmation</li>
              <li className={activeTab === "Marriage" ? "active":""} onClick={handleMarriage}>Marriage</li>
            </ul>
            <div className="outlet">

        {(activeTab === "Baptism") ? ( Object.keys(baptism).length > 0 ? <Baptism admin={true} userData={userData} baptismData={baptism}/>: <p className=' text-center font-bold text-xl'> {userData.name + " " + userData.surname} is not yet Baptised !</p>) : <></> }
        {activeTab === "Confirmation" ? (Object.keys(confirmation).length > 0 ? <Confirmation admin={true} userData={userData} confirmationData={confirmation} /> : <p className=' text-center font-bold text-xl'> {userData.name + " " + userData.surname} is not yet Confirmed !</p>) : <></>}
        {activeTab === "Marriage" ? (Object.keys(marriage).length > 0 ? <Marriage admin={true} userData={userData}  marriageData={marriage} /> : <p className=' text-center font-bold text-xl'> {userData.name + " " + userData.surname} is not yet Married !</p>) : <></>}
          
              {/* content will be shown here */}
              {/* {activeTab === "Baptism" ? <Baptism  admin={false} userData={userData} baptismData={baptism}/>: <></>}
              {activeTab === "Confirmation" ? <Confirmation confirmationData={confirmation} admin={false} userData={userData}/> : <></>}
              {activeTab === "Marriage" ? <Marriage marriageData={marriage} admin={false} userData={userData}/> : <></>} */}
          
            </div>
        </div>

        <h3 className='text-center font-bold text-xl text-white'>Transaction History</h3>

            {(payments.length > 0) ? (payments.map( (pay,index) =>{
              return <Transaction amountPayed={pay.amountPayed} date={pay.date} reference={pay.reference}/>
            })) 
           :(<h1 className=' font-bold text-center text-white'>There are no Payments made to the church!</h1> )}

           <h3 className='text-center font-extrabold text-xl mt-5 text-white text-xl'>Church Events</h3>

           {events.length > 0 ? (
                  events.map((event) => {
          return <Event eventTitle={event.eventTitle} eventDate={event.eventDate} description={event.eventDescription}/>
        })
        
        ) : ( <h1 className=' text-center font-bold text-xl'>There are no Events yet!</h1>) } 

      </div>
  
    </div>
  </div>
  )
}

export default Member