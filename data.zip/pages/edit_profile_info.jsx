import React,{useState} from 'react';
// import Stepper from " ../components/Stepper";
import Stepper from "../Components/Stepper"
import StepperControl from "../Components/StepperControl";
import { UseContextProvider } from "../context/StepperContext";

import PersonalDetails from "../Components/steps/PersonalDetails";
import FathersDetails from "../Components/steps/FathersDetails";
import MotherDetails from "../Components/steps/MotherDetails";
import Final from "../Components/steps/Final";
import { useLocation, useNavigate } from 'react-router-dom';
import { useStateContext } from "../context/ContextProvider";
import axios from 'axios';
import { BsArrowLeft } from 'react-icons/bs';



const Edit_profile_info = () => {
  const navigate = useNavigate()
  const [currentStep, setCurrentStep] = useState(1);

  const memberPersonalDetails = {
    surname:"", 
    name:"", 
    dateOfBirth:"", 
    idNumber: "" ,
    placeOfBirth:"",
    birthPlace:""
  }
  const memberFatherDetails = {
    surname:"", 
    name:"", 
    dob:"", 
    country:"",
    idNumber: "" ,
    birthPlace:""
  }
  const memberMotherDetails = {
    surname:"", 
    name:"", 
    dob:"", 
    country:"",
    idNumber: "" ,
    birthPlace:""
  }

  const { membersMother, setMembersMother,setMembersFather,membersFather,setMemberDetails,memberDetails} = useStateContext();
  const [success,setSuccess] = useState(false);

  var location = useLocation();

  var userData = location.state.userData;
  var newMember = location.state.newMember;

  console.log("We received the userDat in edit_profile page")
  console.log(userData);
  console.log(`new member= ${newMember}`);

  const steps = [
    "Personal Details",
    "Father's Details",
    "Mother's Details",
    "Complete",
  ];

  const clearContext = () => {
  // memberPersonalDetails
  // memberFatherDetails
  // memberMotherDetails

setMembersMother(memberMotherDetails);
setMembersFather(memberFatherDetails);
setMemberDetails(memberPersonalDetails);


  }

  const displayStep = (step) => {

    if(newMember){
      switch (step) {
        case 1:
        // Then we are creating a new member
         return <PersonalDetails newMember={true}/>;
        case 2:
          return <FathersDetails newMember={true} />;
        case 3:
          return <MotherDetails newMember={true} />;
        case 4:
          return <Final />;
        default:
      }
    }else{
      switch (step) {
        case 1:
          // We are updating the member
        return <PersonalDetails userData={userData}/>;
        case 2:
          return <FathersDetails userData={userData} />;
        case 3:
          return <MotherDetails userData={userData} />;
        case 4:
          return <Final />;
        default:
      }
    }

    // switch (step) {
    //   case 1:
    //     if(newMember){
    //       // Then we are creating a new member
    //       return <PersonalDetails newMember={true}/>;
    //     }else{
    //       // We are updating the member
    //       return <PersonalDetails userData={userData}/>;
    //     }
    //   case 2:
    //     return <FathersDetails userData={userData} />;
    //   case 3:
    //     return <MotherDetails userData={userData} />;
    //   case 4:
    //     return <Final />;
    //   default:
    // }
  };

  const handleClick = (direction) => {
    let newStep = currentStep;

    direction === "next" ? newStep++ : newStep--;
    // check if steps are within bounds
    newStep > 0 && newStep <= steps.length && setCurrentStep(newStep);
    if(currentStep === steps.length - 1){
        console.log("WE CAN SEND THE DATA TO THE BACK END")
        console.log(memberDetails)
        console.log(membersFather)
        console.log(membersMother)

  var data = {
  name: memberDetails.name,
  surname: memberDetails.surname,
  dateOfBirth: memberDetails.dateOfBirth,
  idNumber: memberDetails.idNumber,
  placeOfBirth: memberDetails.birthPlace,
  fatherName: membersFather.name,
  fatherSurname: membersFather.surname,
  fatherDOB: membersFather.dateOfBirth,
  fatherPlaceOfBirth: membersFather.birthPlace,
  fatherCountry: membersFather.country,
  fatherIdNumber: membersFather.idNumber,
  motherSurname: membersMother.surname,
  motherName: membersMother.name,
  motherDOB: membersMother.dob,
  motherPlaceOfBirth: membersMother.birthPlace,
  motherCountry: membersMother.country,
  motherIdNumber: membersMother.idNumber,
  }
  console.log("Printing the processed data----------FINAL DATA TO BE SEND TO DB")
  console.log(data);

    sendData(data);

    }
  };
  const sendData = async (data) =>
  {
    console.log("Sending the data to the backend now-----------------------------------------------------------");
    if(newMember){

      // Then we are creating a new Member
      console.log("PRINTING THE DATA IN EDIT_PROFILE_INFO")
      console.log(data);
      console.log(" NEW MEMBER === True")

      // Processing the idNumber 

      //ID = dob + 
    
      var dob = data.dateOfBirth.replaceAll('/','')
      var name = data.name.charAt(0);
      var surname = data.surname.charAt(0);
      var newId = dob+name+ surname;

      console.log(`Printing the new id ${newId}`);
      console.log(newId);



      console.log(`Printing the new DATE OF BIRTH ${dob}`);
      console.log(dob);


      const response = axios.post('http://localhost:3000/newMember/',{
        name:data.name,
        idNumber:newId,
        surname:data.surname,
        dateOfBirth:data.dateOfBirth,
        placeOfBirth:data.placeOfBirth,
        fatherName:data.fatherName,
        fatherSurname:data.fatherSurname,
        fatherDOB:data.fatherDOB,
        fatherPlaceOfBirth:data.fatherPlaceOfBirth,
        fatherCountry:data.fatherCountry,
        fatherIdNumber:data.fatherSurname,
        motherSurname:data.motherSurname,
        motherName:data.motherName,
        motherDOB:data.motherDOB,
        motherPlaceOfBirth:data.motherPlaceOfBirth,
        motherCountry:data.motherCountry,
        motherIdNumber:data.motherIdNumber
        })
        .then( (res) =>{
          if(res.status === 200){
            console.log(res);
            console.log("The data has been INSERTED")
            setSuccess(true);
          }else{
            console.log(res);
            console.log("AN error has occurred while INSERTING the members data")
          }
        }).catch((error) =>{
          console.log(`an error has occured ${error}`);
        });

       


    }else{
      console.log(" NEW MEMBER === FALSE")
      const response = axios.put(`http://localhost:3000/updateMember/${data.idNumber}`,{
        name:data.name,
        surname:data.surname,
        dateOfBirth:data.dateOfBirth,
        placeOfBirth:data.placeOfBirth,
        fatherName:data.fatherName,
        fatherSurname:data.fatherIdNumber,
        fatherDOB:data.fatherDOB,
        fatherPlaceOfBirth:data.fatherPlaceOfBirth,
        fatherCountry:data.fatherCountry,
        fatherIdNumber:data.fatherSurname,
        motherSurname:data.motherSurname,
        motherName:data.motherName,
        motherDOB:data.motherDOB,
        motherPlaceOfBirth:data.motherPlaceOfBirth,
        motherCountry:data.motherCountry,
        motherIdNumber:data.motherIdNumber
        })
        .then( (res) =>{
          if(res.status === 200){
            console.log(res);
            console.log("The data has been updated")
            setSuccess(true);
           
          }else{
            console.log(res);
            console.log("AN error has occurred while updating the members data")
          }
        })
    }

      // Clearing the form fields after we have send the data to the backends
    clearContext();

  }

  const nav = () =>{
    navigate(-1);
  }

  return (
    <div className=''>
        <div className=' float-left m-2'>
              <button type='button' onClick={nav}  style={{ color:'#03C9D7',backgroundColor:'#e5fafb'}} className="text-2xl opacity-0.9 p-4 hover:drop-shadow-xl rounded-lg">
                <BsArrowLeft />
              </button>
          </div>
    <div className="mx-auto rounded-2xl bg-slate-800 pb-2 shadow-xl md:w-1/2 mt-5">
      {/* Stepper */}
      <div className="horizontal container mt-5 ">
        <Stepper steps={steps} currentStep={currentStep} />

        <div className="my-10 p-10 ">
          <UseContextProvider>{displayStep(currentStep)}</UseContextProvider>
        </div>
      </div>

      {/* navigation button */}
      {currentStep !== steps.length && (
        <StepperControl
          handleClick={handleClick}
          currentStep={currentStep}
          steps={steps}
        />
      )}
    </div>
    </div>

  );
}

export default Edit_profile_info