import React,{useEffect,useState} from 'react'
import { useLocation } from 'react-router-dom';
// import NewBaptism from '../Components/NewBaptism';
// import NewConfirmation from '../Components/NewConfirmation';
// import NewMarriage from '../Components/NewMarriage';

import  {useNavigate  } from 'react-router-dom'
import { ColumnDirective, ColumnsDirective, GridComponent,Grid } from '@syncfusion/ej2-react-grids';
import { ordersData, contextMenuItems, ordersGrid } from '../data/dummy';
import Header from "../Components/Header"
import { Inject, Search, Toolbar } from '@syncfusion/ej2-react-grids';
import axios from 'axios';


const NewRecord = () => {
    var location = useLocation()

    // console.log(location.state.type)
  
    const type = location.state.type;
    const userData = location.state.userData;
    const [members,setMembers] = useState([]);
  
    useEffect( () =>{
      const response = axios.get("http://localhost:3000/members").then((res) =>{
  
        if(res.data.length > 0){
  
          console.log("We got something from the backend")
          console.log(res.data);
          setMembers(res.data);
        }else{
          console.log("We got an empty list from the backend");
        }
      }).catch( (error) =>{
        console.log(error);
      })
    },[])

    var navigate = useNavigate();

    var handleNav = (data) =>{
      if(type === "Baptised"){
        navigate("/new_baptism",{state:{data:data}})
      }else if(type === "Confirmed"){
        navigate("/new_confirmation",{state:{data:data}})
      }else{
        navigate("/new_marriage",{state:{data:data}})
      }
    }

    const rowSelected = (grid) => {
     
     console.log(grid);
       if (grid) {
        handleNav(grid.data);
        //navigate("/profile",{state:{ memberData:grid.data,fatherData:grid.data,motherData:grid.data}});
        console.log("Printing the CLICKED ON DATA IN MEMBERS")
         console.log(grid.data);
       }   
   }

  //  const nav = () =>{
  //     navigate("/edit_profile")
  //  }
 
   return (
    
     <div className="m-2 md:m-10 p-2 md:p-10 bg-white rounded-3xl border-2">

      <Header title={`Please select member to be ${type}`}/>

      <div className='mt-10'>
      <GridComponent
       id='gridcomp'
       dataSource={members}
       toolbar={["Search"]}
       allowSorting
       allowPaging
        rowSelected={rowSelected}
      >
 
         <ColumnsDirective>
           {ordersGrid.map((item,index,) => (
             <ColumnDirective key={index} {...item}/>
           ))}
         </ColumnsDirective>
         <Inject services={[Search, Toolbar]}/>
       </GridComponent>
      </div>
    

     </div>
   )
}

export default NewRecord