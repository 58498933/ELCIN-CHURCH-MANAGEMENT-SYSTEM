import React from 'react'
import trees from "../assets/trees.jpg"
import { useLocation } from 'react-router-dom';
import RegisterAdmin from "../Components/RegisterAdmin"
import RegisterMember from "../Components/RegisterMember"

const Register = () => {

var location = useLocation();
var checkAdmin = true;
var type = location.state.type;

console.log(`The received type in register is: ${type}`);

if(type === "Admin"){

    return (<RegisterAdmin/>);

}else {
    return( <RegisterMember/> );
}


}

export default Register