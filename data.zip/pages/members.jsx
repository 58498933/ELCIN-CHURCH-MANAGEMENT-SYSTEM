import React,{useEffect,useState} from 'react';
import  {useNavigate  } from 'react-router-dom'
import { ColumnDirective, ColumnsDirective, GridComponent,Grid } from '@syncfusion/ej2-react-grids';
import { ordersData,ordersGrid } from '../data/dummy';
import Header from "../Components/Header"
import { Inject, Search, Toolbar } from '@syncfusion/ej2-react-grids';
import { IoIosAddCircleOutline } from 'react-icons/io';
import axios from "axios";
import { useStateContext } from '../context/ContextProvider';



// In these page, get the All the MembersData,FathersData,MothersData then send it to the next page

const Members = () => {
  const { currentColor, activeMenu, setActiveMenu, handleClick, isClicked, setScreenSize, screenSize } = useStateContext();
  var navigate = useNavigate();
  const [members,setMembers] = useState([]);


  useEffect( () =>{
    const response = axios.get("http://localhost:3000/members").then((res) =>{

      if(res.data.length > 0){

        console.log("We got something from the backend")
        console.log(res.data);
        setMembers(res.data);
      }else{
        console.log("We got an empty list from the backend");
      }
    }).catch( (error) =>{
      console.log(error);
    })
  },[])

    const rowSelected = (grid) => {
     
     console.log(grid);
       if (grid) {
        console.log("Printing the CLICKED ON DATA IN MEMBERS")
        console.log(grid.data);
        navigate("/profile",{state:{ memberData:grid.data}});
        
       }   
   }

   const nav = () =>{
      navigate("/edit_profile",{state:{newMember:true}})
   }
 
   return (
     <div className="m-2 md:m-10 p-2 md:p-10 bg-white rounded-3xl">
      {/* <Header title={"Baptism book"}/> */}
      <div>
        <p className='float-left text-3xl font-extrabold tracking-tight text-slate-900'>All Members <span className=' font-medium text-xl'> Total Members {members.length}</span></p>
        <button type='button' onClick={nav}  style={{ color:'#03C9D7',backgroundColor:'#E5FAFB'}} className="rounded-3xl opacity-0.9 p-2 hover:drop-shadow-xl float-right">
         <IoIosAddCircleOutline />
        </button>
      </div>
   

      <div className='mt-10'>
      <GridComponent
       id='gridcomp'
       dataSource={members}
       toolbar={["Search"]}
       allowSorting
       allowPaging
        rowSelected={rowSelected} 
      >
 
         <ColumnsDirective>
           {ordersGrid.map((item,index,) => (
             <ColumnDirective key={index} {...item}/>
           ))}
         </ColumnsDirective>
         <Inject services={[Search, Toolbar]}/>
       </GridComponent>
      </div>
    

     </div>
   )
}

export default Members