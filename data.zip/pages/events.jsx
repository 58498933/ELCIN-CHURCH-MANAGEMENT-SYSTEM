import React,{useEffect,useState} from 'react'
import { FiEdit } from 'react-icons/fi';
import Event from '../Components/event';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const Events = () => {
    var navigate = useNavigate();
    const[events,setEvents] = useState([]);
    const[deleted,setDeleted] = useState(false);

    const nav = () => {
        navigate("/new_event",)
    }


    useEffect( () =>{
      console.log("Getting the event data ---------------------------------------")
        const response = axios.get("http://localhost:3000/events").then( (res) => {
          if(res.data.length > 0){
            console.log("we got the events data")
            console.log(res.data)
            setEvents(res.data);

          }else{
            console.log("The event data from the database is empty");
            setEvents([]);
          }
        }).catch((error) => {
          console.log(error);
        })
    },[deleted])

    const deleteEvent = (event) =>{
      console.log("Printing the received event: ");
      console.log(event);

      const deletEvent = axios.delete(`http://localhost:3000/deletEvent/${event.eventId}`).then( (res) =>{

      if(res.status === 200){
        console.log("The event has been deleted successfully! ")
        setDeleted(!deleted);

      }else{
        console.log("An error has occurred! ");
      }

      }).catch( (error) => {
        console.log(`An error has occured ${error}`);
      })

    }

  return (
    <div >
        <div className=' ml-5 mr-5'>
          <div className=' float-right m-2'>
            <button type='button' onClick={nav}  style={{ color:'#03C9D7',backgroundColor:'#E5FAFB'}} className="text-2xl opacity-0.9 p-4 hover:drop-shadow-xl rounded-lg">
                <FiEdit />
            </button>
            <p className=' ml-3 text-white'>New</p>
          </div>
        </div>

        {events.length > 0 ? (
                  events.map((event) => {
          return <Event eventTitle={event.eventTitle} eventDate={event.eventDate} description={event.eventDescription} deleteEvent={del => deleteEvent(event)}/>
        })
        ) : ( <h1 className=' text-center font-bold text-xl text-white'>There are no Events yet!</h1>)}

    </div>


  )
}

export default Events