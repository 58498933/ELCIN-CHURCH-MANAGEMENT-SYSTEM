import React,{useState} from 'react';
import Stepper from "../Components/Stepper"
import StepperControl from "../Components/StepperControl";
import { UseContextProvider } from "../context/StepperContext";
import { useStateContext } from '../context/ContextProvider';

import Church from "../Components/steps/marriage/Church"
import Female from "../Components/steps/marriage/Female"
import Male from "../Components/steps/marriage/Male"
// import ChurchDetails from "../Components/steps/confirmation/ChurchDetails"
import Final from "../Components/steps/Final";
import axios from 'axios';


const EditMarriage = ({userData,marriageData}) => {
    const [currentStep, setCurrentStep] = useState(1);
    const {churchDetails,marriageSpouse} = useStateContext();

    const steps = [
      "Spouse Details",
      "Church Details",
      "Complete",
    ];

// bishopName: "Petrus",
// churchAddress: "Ohalushu",
// churchName: "ELCIN",
// dateOfMarriage: "10 Aug 2202",
// idNumber: "5555"
// marriagePlace: "Ongha"
// spouseAddress: "Ongha"
// spouseFatherName: "Elenga"
// spouseFatherSurname: "Walye"
// spouseGender: "Female"
// spouseIdNumber: "20071900512"
// spouseMotherName: "Teopoline"
// spouseMotherSurname: "Endjala"
// spouseName: "Niks"
// spouseSurname: "Elenga"
// spouseTelephone: "555554"

var churchData = {
  churchName:marriageData.churchName,
  churchAddress:marriageData.churchAddress,
  marriagePlace:marriageData.marriagePlace,
  bishopName:marriageData.bishopName,
  dateOfMarriage:marriageData.dateOfMarriage,
}
  
    const displayStep = (step) => {
      switch (step) {
        case 1:
          return  <Female newSpouse={false} marriageData={marriageData} />;
        case 2:
          return  <Church  churchData={churchData}/>;
        case 3:
            return <Final/>;
        default:
      }
    };
  
    const handleClick = (direction) => {
      let newStep = currentStep;
  
      direction === "next" ? newStep++ : newStep--;
      // check if steps are within bounds
      newStep > 0 && newStep <= steps.length && setCurrentStep(newStep);
      if(currentStep === steps.length - 1){

      // bishopName: "Petrus"
// churchAddress: "Ohalushu"
// churchName: "ELCIN"
// dateOfMarriage: "10 Aug 2202"
// idNumber: "5555"
// marriagePlace: "Ongha"
// spouseAddress: "Ongha"
// spouseFatherName: "Elenga"
// spouseFatherSurname: "Walye"
// spouseGender: "Female"
// spouseIdNumber: "20071900512"
// spouseMotherName: "Teopoline"
// spouseMotherSurname: "Endjala"
// spouseName: "Niks"
// spouseSurname: "Elenga"
// spouseTelephone: "555554"



// bishopName: "Petrus",
// churchAddress: "Ohalushu",
// churchName: "ELCIN",
// dateOfMarriage: "10 Aug 2202",
// idNumber: "5555"
// marriagePlace: "Ongha"
// spouseAddress: "Ongha"
// spouseFatherName: "Elenga"
// spouseFatherSurname: "Walye"
// spouseGender: "Female"
// spouseIdNumber: "20071900512"
// spouseMotherName: "Teopoline"
// spouseMotherSurname: "Endjala"
// spouseName: "Niks"
// spouseSurname: "Elenga"
// spouseTelephone: "555554"

            const spouseDetails = {
  surname:"", 
  name:"", 
  fatherName:"", 
  motheName: "", 
  address: "",
  telephone:"",
  sex:"",
  dob:"", 
  idNumber: "",

                                  }

// const churchMarriage = {
//   churchName:"", 
//   marriagePlace:"", 
//   bishopName: "", 
//   churchAddress: "",
//   dateOfMarriage:"",
// }


        var data = {
          bishopName:churchDetails.bishopName,
          churchAddress:churchDetails.churchAddress,
          churchName:churchDetails.churchName,
          dateOfMarriage:churchDetails.dateOfMarriage,
          marriagePlace: churchDetails.marriagePlace,
          spouseAddress:marriageSpouse.address,
          spouseFatherName:marriageSpouse.fatherName,
          spouseGender: marriageSpouse.sex,
          spouseIdNumber:marriageSpouse.idNumber,
          spouseMotherName:marriageSpouse.motherName,
          spouseName:marriageSpouse.name,
          spouseSurname:marriageSpouse.surname,
          spouseTelephone:marriageSpouse.telephone
                    }

        console.log("PRINTING THE FINAL DATA");
        console.log(data);

        sendData(data);

        


 }
     
    };

    const sendData = (data) =>{

      const response = axios.put(`http://localhost:3000/updateMarriage/${marriageData.idNumber}`,data).then((res) =>{
        // 
        if(res.status === 200){
          console.log(" WE HAVE SUCCESSFULLY UPDATED THE DATA")
          console.log(res)
        }else{
          console.log("AN ERROR HAS OCCURED, WE DID NOT UPDATE THE RECORD")
          console.log(res)
        }
      }).catch( (error) =>{
        console.log(error);
      })

    }
  
    return (
      <div className="mx-auto rounded-2xl bg-white pb-2 shadow-xl md:w-1/2">
        {/* Stepper */}
        <div className="horizontal container mt-5 ">
          <Stepper steps={steps} currentStep={currentStep} />
  
          <div className="my-10 p-10 ">
            <UseContextProvider>{displayStep(currentStep)}</UseContextProvider>
          </div>
        </div>
  
        {/* navigation button */}
        {currentStep !== steps.length && (
          <StepperControl
            handleClick={handleClick}
            currentStep={currentStep}
            steps={steps}
          />
        )}
      </div>
    );
}

export default EditMarriage