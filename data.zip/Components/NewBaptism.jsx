import React ,{useState} from 'react'
import { useNavigate } from 'react-router-dom';
import { useLocation } from 'react-router-dom';
import axios from 'axios';
import { BsArrowLeft } from 'react-icons/bs';

const NewBaptism = () => {
  var navigate = useNavigate();
  var location = useLocation()
  const userData = location.state.data;

  console.log("Received UserData")
  console.log(userData);
      
  var navigate = useNavigate();
  const initialValues = { baptismDate: "", baptismPlace: "" ,churchName:"",churchAddress:"",pastorsName:""};
  const initialFormErrors = {};
  const [formValues, setFormValues] = useState(initialValues);
  const [formErrors, setFormErrors] = useState(initialFormErrors);
  // const [error,setError] = useState("");
  const [isSubmit, setIsSubmit] = useState(false);

  // const {setAdmin} = useStateContext()

  const handleChange = (e) => {
      console.log(e);
      const { name, value } = e.target;
      setFormValues({ ...formValues, [name]: value });
    };

    const handleSubmit = (e) =>  {
      console.log("submitted the form");
      e.preventDefault();
      var formError = validate(formValues);

      setFormErrors(formError);
      console.log("Printing the form errors")
      console.log(formError);
      console.log(formErrors);
      setIsSubmit(true);
      // sending the data to the backend
      // try{


        if(Object.keys(formErrors).length === 0){
          console.log("There are no errors we can navigate")

    //           "placeOfBaptism": "ongha",
    // "dateOfBaptism": "10 Aug 2020",

            const response = axios.post("http://localhost:3000/newBaptism",JSON.stringify({
                idNumber:userData.idNumber,
                placeOfBaptism:formValues.baptismDate,
                placeOfBaptism:formValues.baptismPlace,
                churchName:formValues.churchName,
                churchAddress:formValues.churchAddress 
              }),{
                  headers: { 'Content-Type': 'application/json' },
                  withCredentials: false
              }).then( (res) =>{

                if(res.status === 200){
                  console.log("Confirmation data was added! ")
                  navigate(-1);
                }

              }).catch( (error) => {
                  console.log(error);
              });
          
        }else{
          console.log("The formErrors is not Empty")
        }

        


    };


  const validate = (values) => {
      console.log("Validating the form")
      console.log(values);
      const errors = {}; 
      const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i; 
      if (!values.email) {
        errors.email = "Email is required!";
      } else if (!regex.test(values.email)) {
        errors.email = "This is not a valid email format!";
      }
      if (!values.password) {
        errors.password = "Password is required";
      } else if (values.password.length < 4) {
        errors.password = "Password must be more than 4 characters";
      } else if (values.password.length > 30) {
        errors.password = "Password cannot exceed more than 30 characters";
      }
      console.log(errors)
      return errors;
    };

  const nav = () =>{
    navigate(-1);
  }


return (
  
<div className='flex flex-col justify-center'>
<div className=' float-left m-2'>
                  <button type='button' onClick={nav}  style={{ color:'#03C9D7',backgroundColor:'#e5fafb'}} className="text-2xl opacity-0.9 p-4 hover:drop-shadow-xl rounded-lg">
                    <BsArrowLeft />
                  </button>
                </div>
  <form className='max-w-[400px] w-full mx-auto  p-4 rounded-lg text-white' onSubmit={handleSubmit}>
      <h2 className='text-4xl font-bold text-center py-6'> Enter Baptism Details</h2>
      <div className='flex flex-col py-2'>
          <label>Place of Baptism</label>
          <input className='border rounded-md p-2 text-black' type="text" 
           name='baptismPlace'
           placeholder='Place of Baptism'
           value={formValues.baptismPlace}
           onChange={handleChange}
          />
      </div>
      <p>{formErrors.email}</p>

      <div className='flex flex-col py-2'>
          <label>Date of Baptism</label>
          <input className='border p-2 rounded-md  text-black' type="text" 
              name='baptismDate'
              placeholder='Date of Baptism'
              value={formValues.baptismDate}
              onChange={handleChange}
          />
      </div>

      {/* <p>{formErrors.password}</p> */}

      <div className='flex flex-col py-2'>
          <label>Church Name</label>
          <input className='border p-2 rounded-md text-black' type="text" 
              name='churchName'
              placeholder="Church's Name"
              value={formValues.churchName}
              onChange={handleChange}
          />
      </div>

      <div className='flex flex-col py-2'>
          <label>Church Address</label>
          <input className='border p-2 rounded-md text-black' type="text" 
              name='churchAddress'
              placeholder='Church Address'
              value={formValues.churchAddress}
              onChange={handleChange}
          />
      </div>

      <div className='flex flex-col py-2'>
          <label>Pastor's Name</label>
          <input className='border p-2 rounded-md text-black' type="text" 
              name='pastorsName'
              placeholder="Pastor's Name"
              value={formValues.pastorsName}
              onChange={handleChange}
          />
      </div>

      <button className='border w-full my-5 rounded-lg py-2 hover:bg-indigo-500 text-white' >Save</button>
  </form>
</div>
)
}

export default NewBaptism