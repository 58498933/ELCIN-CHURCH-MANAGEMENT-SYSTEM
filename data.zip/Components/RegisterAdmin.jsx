import React,{useState,useEffect} from 'react'
import { useNavigate } from 'react-router-dom';
import Stepper from "../Components/Stepper"
import StepperControl from "../Components/StepperControl";
import { UseContextProvider } from "../context/StepperContext";

import MembersDetails from "../Components/steps/baptism/MembersDetails"
import Final from "../Components/steps/Final";
import ChurchDetails from './steps/register/ChurchDetails';
import PersonalDetails from './steps/register/PersonalDetails';
import { DropDownListComponent } from '@syncfusion/ej2-react-dropdowns';
import axios from "axios"

const RegisterAdmin = () => {
 
      
  var navigate = useNavigate();
  const initialValues = { surname: "", name: "" ,idNumber:"",email:"",password:"",confirmPassword:""};
  const initialFormErrors = {};
  var allErrors = {};
  const [formValues, setFormValues] = useState(initialValues);
  var [formErrors, setFormErrors] = useState(initialFormErrors);
  const [churches,setChurches] = useState([])
  const [churchId,setChurchId] = useState("");

  // const [error,setError] = useState("");
  const [isSubmit, setIsSubmit] = useState(false);


  const getValue = (data)=>{
    console.log("Print the loaded value")
    console.log(data)
    setChurchId(data.value)
  }

  useEffect( () =>{
    const response = axios.get("http://localhost:3000/churches").then( (res) =>{
     
      if(res.data.length > 0){
        console.log("We got all the churches from the backend no errors")
        console.log(res.data)
        var data = res.data;
        var churches = [];
        data.forEach(element => {
          // 
          churches.push(element.churchName); 
        });

        setChurches(churches);
      }else{
        console.log("An error has occured")
      }

    }).catch((error) =>{
      console.log(`An error has occurred!! ${error}`)
    })
  },[])

  // const {setAdmin} = useStateContext()

  const handleChange = (e) => {
      console.log(e);
      const { name, value } = e.target;
      setFormValues({ ...formValues, [name]: value });
    };

    const handleSubmit = (e) =>  {
      console.log("submitted the form");
      e.preventDefault();

      // var formError = validate(formValues);
      setFormErrors(validate(formValues));
      console.log("Printing the form errors")
      // console.log(formError);
      console.log(formErrors);
      setIsSubmit(true);
      // sending the data to the backend


      // Meaning we have errors?
      if(Object.keys(allErrors).length === 0 && churchId.length > 0){
        console.log(`The formErrors obj is empty ${formErrors}`)
        console.log(`The formErrors length ${Object.keys(formErrors).length}`)
        console.log(formErrors);
        console.log(allErrors);
        console.log("Can send the data to the backend")
        const response = axios.post("http://localhost:3000/newAdmin",JSON.stringify({email:formValues.email,password:formValues.password,name:formValues.name,idNumber:formValues.idNumber,churchId:churchId,surname:formValues.surname}),{
              headers: { 'Content-Type': 'application/json' },
              withCredentials: false
          }).then( (res) => {

            console.log("Received data from the backend")
            console.log(res);

            if(res.status === 200){
                navigate(-1);
            }

          }).catch( (error) => {
            console.log(` an error has occured ${error}`)
          })
      }else{
        console.log("THERES AN ERROR")
        console.log(formErrors);
        console.log(allErrors);
        console.log(`The formErrors length ${Object.keys(formErrors).length}`)
      }
    };

  const validate = (values) => {
      console.log("Validating the form")
      console.log(values);
      const errors = {}; 
      const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i; 
      if (!values.email) {
        errors.email = "Email is required!";
      } else if (!regex.test(values.email)) {
        errors.email = "This is not a valid email format!";
      }
      if (!values.password) {
        errors.password = "Password is required";
      } else if (values.password.length < 4) {
        errors.password = "Password must be more than 4 characters";
      } else if (values.password.length > 30) {
        errors.password = "Password cannot exceed more than 30 characters";
      } 
      
      if(values.password !== values.confirmPassword){
        errors.password = "The entered passwords don't match"
      }

      if(!values.surname){
        errors.surname = "Please enter your surname"
      }
      if(!values.name){
        errors.name = "Please enter your full name"
      }
      if(!values.idNumber){
        errors.dateOfBirth = "Please enter your Id Number"
      }
      console.log(errors)
      setFormErrors(errors);
      allErrors = errors;
      return errors;
    };


return (
  
<div className='flex flex-col justify-center'>
  <form className='max-w-[400px] w-full mx-auto  p-4 rounded-lg text-white' onSubmit={handleSubmit}>
      <h2 className='text-4xl font-bold text-center py-6 text-white'> Create a new Account</h2>
      <div className='flex flex-col py-2'>
          <label >Surname</label>
          <input className='border rounded-md p-2 text-black' type="text" 
           name='surname'
           placeholder='Surname'
           value={formValues.surname}
           onChange={handleChange}
          />
      </div>
      <p className=' text-red-700' >{formErrors.surname}</p>

      <div className='flex flex-col py-2'>
          <label>Full Names</label>
          <input className='border p-2 rounded-md text-black' type="text" 
              name='name'
              placeholder='Full names'
              value={formValues.name}
              onChange={handleChange}
          />
      </div>
      <p className=' text-red-700'>{formErrors.name}</p>

      {/* <p>{formErrors.password}</p> */}

      <div className='flex flex-col py-2'>
          <label>Id Number</label>
          <input className='border p-2 rounded-md text-black' type="text" 
              name='idNumber'
              placeholder="Id Number"
              value={formValues.idNumber}
              onChange={handleChange}
          />
      </div>
      <p className=' text-red-700' >{formErrors.dateOfBirth}</p>

      <div className='flex flex-col py-2'>
          <label>Email</label>
          <input className='border p-2 rounded-md text-black' type="text" 
              name='email'
              placeholder='Email'
              value={formValues.email}
              onChange={handleChange}
          />
      </div>
      <p className=' text-red-700'>{formErrors.email}</p>

      <div className='flex flex-col py-2'>
          <label>Password</label>
          <input className='border p-2 rounded-md text-black' type="text" 
              name='password'
              placeholder="password"
              value={formValues.password}
              onChange={handleChange}
          />
      </div>
      <p className=' text-red-700'>{formErrors.password}</p>
      <div className='flex flex-col py-2'>
          <label>Confirm Password</label>
          <input className='border p-2 rounded-md text-black' type="text" 
              name='confirmPassword'
              placeholder="confirmPassword"
              value={formValues.confirmPassword}
              onChange={handleChange}
          />
      </div>
      <p className=' text-red-700'>{formErrors.password}</p>

      <div className="w-full mx-2 flex-1">
          <div className="font-bold h-6 mt-3 text-gray-500 text-xs leading-8 uppercase">
            Choose your church
          </div>
            <DropDownListComponent id='ddlelement' dataSource={churches} placeholder="Select a church" change={getValue} />
        </div>

      <button className='border w-full my-5 rounded-lg py-2 hover:bg-indigo-500 text-white' >Create Account</button>
  </form>
</div>
)
}

export default RegisterAdmin