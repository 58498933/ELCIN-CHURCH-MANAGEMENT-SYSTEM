import React from 'react'

const Transaction = ({amountPayed,date,reference,outstanding}) => {
  return (
    <div> 
    <div className='rounded-md m-1 mt-5 h-2/4 w-2/4 border text-white '>
        <h3 className=' font-bold text-xl m-2 '><span className=' font-extrabold text-2xl text-indigo-100'>Amount payed: </span>N$ {amountPayed}</h3>
        <h3 className=' text-xl font-semibold mt-2 m-2'><span className='font-extrabold text-2xl text-indigo-100'>Date: </span>{date}</h3>
        <h3 className=' text-xl font-semibold mt-2 m-2'><span className=' font-extrabold text-2xl text-indigo-100'>Reference: </span>{reference}</h3>
        {/* <h3 className=' text-xl font-semibold mt-2 m-2'><span className='font-extrabold text-2xl'>Outstanding: N$ </span>{outstanding}</h3> */}
    </div>
  </div>
  )
}

export default Transaction