import React from 'react'
import {MdDelete} from "react-icons/md"

const Event = ({eventTitle,description,eventDate,deleteEvent}) => {
  return (
    <div className=' m-1 mt-5 h-2/4 w-2/4 rounded-md border-2 text-indigo-300' >
        <div className=' float-right m-2'>
          <button type='button' onClick={deleteEvent}  style={{ color:'#03C9D7',backgroundColor:'#e5fafb'}} className="text-2xl opacity-0.9 p-2 hover:drop-shadow-xl rounded-lg">
                <MdDelete />
          </button>
             
          </div>
      <div className=' m-2'>
          <h3 className=' font-bold text-xl mt-2  text-white'><span className=' font-extrabold text-2xl text-indigo-300'>Event Title : </span> {eventTitle}</h3>
          <h3 className=' text-xl font-semibold mt-2 text-white'> <span className='font-extrabold text-2xl text-indigo-300'>Event description : </span>{description}</h3>
          <h3 className=' text-xl font-semibold mt-2 text-white'> <span className=' font-extrabold text-2xl text-indigo-300'>Event Date : </span>{eventDate}</h3>
      </div>
</div> 
  )
}

export default Event