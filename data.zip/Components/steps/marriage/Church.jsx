import React,{useEffect, useState} from 'react'
import { useStateContext } from '../../../context/ContextProvider';

const Church = ({churchData}) => { 
  const {churchDetails,setChurchDetails} = useStateContext();

  console.log("WE RECEIVED CHURCH DATA")
  console.log(churchData)

  const initialValues = {
  surname:churchData !== undefined ? churchData : "", 
  churchName: churchData !== undefined ? churchData.churchName : "", 
  marriagePlace:churchData !== undefined ? churchData.marriagePlace : "", 
  bishopName: churchData !== undefined ? churchData.bishopName : "", 
  churchAddress: churchData !== undefined ? churchData.churchAddress : "",
  dateOfMarriage:churchData !== undefined ? churchData.dateOfMarriage : ""}

  const [fetched,setFetched] = useState(false);


  useEffect( () =>{
    if(!fetched){
      // We only want to get the data once
      setChurchDetails(initialValues)
      setFetched(true);
    }

  },[churchData])

    // bishopName: "Petrus"
    // churchAddress: "Ohalushu"
    // churchName: "ELCIN"
    // dateOfMarriage: "10 Aug 2202"
    // idNumber: "5555"
    // marriagePlace: "Ongha"
    // spouseAddress: "Ongha"
    // spouseFatherName: "Elenga"
    // spouseFatherSurname: "Walye"
    // spouseGender: "Female"
    // spouseIdNumber: "20071900512"
    // spouseMotherName: "Teopoline"
    // spouseMotherSurname: "Endjala"
    // spouseName: "Niks"
    // spouseSurname: "Elenga" ​
    // spouseTelephone: "555554"

  const initialFormErrors = {};
  // const [formValues, setFormValues] = useState(initialValues);
  // const [formErrors, setFormErrors] = useState(initialFormErrors);
  // const [error,setError] = useState("");
  // const [isSubmit, setIsSubmit] = useState(false);

  
    const handleChange = (e) => {
      console.log(e);
      const { name, value } = e.target;
      // setFormValues({ ...formValues, [name]: value });
      setChurchDetails({...churchDetails,[name]: value})
    };


    return (
      <div className="flex flex-col ">

        <div className="w-full mx-2 flex-1">
          <div className="font-bold h-6 mt-3 text-gray-500 text-xs leading-8 uppercase">
            Church Name
          </div>
          <div className="bg-white my-2 p-1 flex border border-gray-200 rounded">
            <input
              onChange={handleChange}
              value={churchDetails.churchName}
              name="churchName"
              placeholder="ChurchName"
              className="p-1 px-2 appearance-none outline-none w-full text-gray-800"
            />
          </div>
        </div>

        <div className="w-full mx-2 flex-1">
          <div className="font-bold h-6 mt-3 text-gray-500 text-xs leading-8 uppercase">
            Church Address
          </div>
          <div className="bg-white my-2 p-1 flex border border-gray-200 rounded">
            <input
              onChange={handleChange}
              value={churchDetails.churchAddress}
              name="churchAddress"
              placeholder="Church Address"
              className="p-1 px-2 appearance-none outline-none w-full text-gray-800"
            />
          </div>
        </div>
  
        <div className="w-full mx-2 flex-1">
          <div className="font-bold h-6 mt-3 text-gray-500 text-xs leading-8 uppercase">
            Marriage Place
          </div>
          <div className="bg-white my-2 p-1 flex border border-gray-200 rounded">
            <input
              onChange={handleChange}
              value={churchDetails.marriagePlace}
              name="marriagePlace"
              placeholder="Marriage Place"
              type="text"
              className="p-1 px-2 appearance-none outline-none w-full text-gray-800"
            />
          </div>
        </div>
  
        <div className="w-full mx-2 flex-1">
          <div className="font-bold h-6 mt-3 text-gray-500 text-xs leading-8 uppercase">
            Bishop Name
          </div>
          <div className="bg-white my-2 p-1 flex border border-gray-200 rounded">
            <input
              onChange={handleChange}
              value={churchDetails.bishopName}
              name="bishopName"
              placeholder=" Bishop Name"
              type="text"
              className="p-1 px-2 appearance-none outline-none w-full text-gray-800"
            />
          </div>
        </div>
  
        <div className="w-full mx-2 flex-1">
          <div className="font-bold h-6 mt-3 text-gray-500 text-xs leading-8 uppercase">
            Date of Marriage
          </div>
          <div className="bg-white my-2 p-1 flex border border-gray-200 rounded">
            <input
              onChange={handleChange}
              value={churchDetails.dateOfMarriage}
              name="dateOfMarriage"
              placeholder="Date of Marriage"
              type="text"
              className="p-1 px-2 appearance-none outline-none w-full text-gray-800"
            />
          </div>
        </div>
  
        {/* <div className="w-full mx-2 flex-1">
          <div className="font-bold h-6 mt-3 text-gray-500 text-xs leading-8 uppercase">
            Country
          </div>
          <div className="bg-white my-2 p-1 flex border border-gray-200 rounded">
            <input
              onChange={handleChange}
              value={userData["city"] || ""}
              name="Country"
              placeholder=" Country"
              type="text"
              className="p-1 px-2 appearance-none outline-none w-full text-gray-800"
            />
          </div>
        </div> */}
        
      </div>
    );
}

export default Church