import React,{useState ,useEffect} from 'react'
import { useStepperContext } from "../../../context/StepperContext";
import { useStateContext } from '../../../context/ContextProvider';

const Female = ({newSpouse,marriageData}) => {
    // const { userData, setUserData } = useStepperContext();

    const {marriageSpouse,setMarriageSpouse} = useStateContext();

    console.log("The received marriageData");
    console.log(marriageData);

    // bishopName: "Petrus"
    // churchAddress: "Ohalushu"
    // churchName: "ELCIN"
    // dateOfMarriage: "10 Aug 2202"
    // idNumber: "5555"
    // marriagePlace: "Ongha"
    // spouseAddress: "Ongha"
    // spouseFatherName: "Elenga"
    // spouseFatherSurname: "Walye"
    // spouseGender: "Female"
    // spouseIdNumber: "20071900512"
    // spouseMotherName: "Teopoline"
    // spouseMotherSurname: "Endjala"
    // spouseName: "Niks"
    // spouseSurname: "Elenga" ​
    // spouseTelephone: "555554"



    const initialValues = {
         surname: marriageData !== undefined ? marriageData.spouseSurname : "",
         name: marriageData !== undefined ? marriageData.spouseName : "",
         fatherName: marriageData !== undefined ? marriageData.spouseFatherName : "",
         motherName: marriageData !== undefined ?  marriageData.spouseMotherName : "", 
         address:  marriageData !== undefined ? marriageData.spouseAddress : "",
         telephone: marriageData !== undefined ? marriageData.spouseTelephone : "",
         sex: marriageData !== undefined ? marriageData.spouseGender : "",
         dob:"", 
         idNumber: marriageData !== undefined ? marriageData.spouseIdNumber : ""};
    const initialFormErrors = {};
    const [formValues, setFormValues] = useState(initialValues);
    const [formErrors, setFormErrors] = useState(initialFormErrors);
    const [error,setError] = useState("");
    const [isSubmit, setIsSubmit] = useState(false);


    useEffect( () =>{
      
      setMarriageSpouse(initialValues)
    },[marriageData])

    
    const handleChange = (e) => {
        console.log(e);
        const { name, value } = e.target;
        //setFormValues({ ...formValues, [name]: value });
        setMarriageSpouse({...marriageSpouse,[name]: value});
      };


  return (
    <div className="flex flex-col ">
      <div className="w-full mx-2 flex-1">
        <div className="font-bold h-6 mt-3 text-gray-500 text-xs leading-8 uppercase">
          Surname
        </div>
        <div className="bg-white my-2 p-1 flex border border-gray-200 rounded">
          <input
            onChange={handleChange}
            value={marriageSpouse.surname}
            name="surname"
            placeholder="surname"
            className="p-1 px-2 appearance-none outline-none w-full text-gray-800"
          />
        </div>
      </div>

      <div className="w-full mx-2 flex-1">
        <div className="font-bold h-6 mt-3 text-gray-500 text-xs leading-8 uppercase">
          Full Names
        </div>
        <div className="bg-white my-2 p-1 flex border border-gray-200 rounded">
          <input
            onChange={handleChange}
            value={marriageSpouse.name}
            name="name"
            placeholder="Full Names"
            type="text"
            className="p-1 px-2 appearance-none outline-none w-full text-gray-800"
          />
        </div>
      </div>

      <div className="w-full mx-2 flex-1">
        <div className="font-bold h-6 mt-3 text-gray-500 text-xs leading-8 uppercase">
          Father's Name
        </div>
        <div className="bg-white my-2 p-1 flex border border-gray-200 rounded">
          <input
            onChange={handleChange}
            value={marriageSpouse.fatherName}
            name="fatherName"
            placeholder="Father's Name"
            type="text"
            className="p-1 px-2 appearance-none outline-none w-full text-gray-800"
          />
        </div>
      </div>

      <div className="w-full mx-2 flex-1">
        <div className="font-bold h-6 mt-3 text-gray-500 text-xs leading-8 uppercase">
          Mother's Name
        </div>
        <div className="bg-white my-2 p-1 flex border border-gray-200 rounded">
          <input
            onChange={handleChange}
            value={marriageSpouse.motherName}
            name="motherName"
            placeholder="Mother's Name"
            type="text"
            className="p-1 px-2 appearance-none outline-none w-full text-gray-800"
          />
        </div>
      </div>

      <div className="w-full mx-2 flex-1">
        <div className="font-bold h-6 mt-3 text-gray-500 text-xs leading-8 uppercase">
          Address
        </div>
        <div className="bg-white my-2 p-1 flex border border-gray-200 rounded">
          <input
            onChange={handleChange}
            value={marriageSpouse.address}
            name="address"
            placeholder=" Address"
            type="text"
            className="p-1 px-2 appearance-none outline-none w-full text-gray-800"
          />
        </div>
      </div>

      <div className="w-full mx-2 flex-1">
        <div className="font-bold h-6 mt-3 text-gray-500 text-xs leading-8 uppercase">
          Telephone
        </div>
        <div className="bg-white my-2 p-1 flex border border-gray-200 rounded">
          <input
            onChange={handleChange}
            value={marriageSpouse.telephone}
            name="telephone"
            placeholder=" Telephone"
            type="text"
            className="p-1 px-2 appearance-none outline-none w-full text-gray-800"
          />
        </div>
      </div>

      <div className="w-full mx-2 flex-1">
        <div className="font-bold h-6 mt-3 text-gray-500 text-xs leading-8 uppercase">
          Id Number
        </div>
        <div className="bg-white my-2 p-1 flex border border-gray-200 rounded">
          <input
            onChange={handleChange}
            value={marriageSpouse.idNumber}
            name="idNumber"
            placeholder="Id Number"
            type="text"
            className="p-1 px-2 appearance-none outline-none w-full text-gray-800"
          />
        </div>
      </div>

      <div className="w-full mx-2 flex-1">
        <div className="font-bold h-6 mt-3 text-gray-500 text-xs leading-8 uppercase">
          Gender
        </div>
        <div className="bg-white my-2 p-1 flex border border-gray-200 rounded">
          <input
            onChange={handleChange}
            value={marriageSpouse.sex}
            name="sex"
            placeholder=" Male/Female/Other"
            type="text"
            className="p-1 px-2 appearance-none outline-none w-full text-gray-800"
          />
        </div>
      </div>

      {/* <div className="w-full mx-2 flex-1">
        <div className="font-bold h-6 mt-3 text-gray-500 text-xs leading-8 uppercase">
          Country
        </div>
        <div className="bg-white my-2 p-1 flex border border-gray-200 rounded">
          <input
            onChange={handleChange}
            value={userData["city"] || ""}
            name="Country"
            placeholder=" Country"
            type="text"
            className="p-1 px-2 appearance-none outline-none w-full text-gray-800"
          />
        </div>
      </div> */}
      
    </div>
  );
}

export default Female