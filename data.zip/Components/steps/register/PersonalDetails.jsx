import React,{useState,useEffect} from 'react'
import { useStepperContext } from "../../../context/StepperContext";
import { useStateContext } from "../../../context/ContextProvider";
import { DropDownListComponent } from '@syncfusion/ej2-react-dropdowns';



const PersonalDetails = () => {
    const { adminRegister,setAdminRegister } = useStateContext();

    const initialValues = { surname:"", name:"", dob:"", email: "", password: "" ,cPassword:""};
    const initialFormErrors = {};
    const [formValues, setFormValues] = useState(initialValues);
    const [formErrors, setFormErrors] = useState(initialFormErrors);
    const [error,setError] = useState("");
    const [isSubmit, setIsSubmit] = useState(false);
    const sports = ['Badminton', 'Cricket', 'Football', 'Golf', 'Tennis'];

    const getValue = (data)=>{
      console.log("Print the loaded value")
      console.log(data)
    }

    const handleChange = (e) => {
      console.log(e);
      const { name, value } = e.target;
      // setFormValues({ ...formValues, [name]: value });
      setAdminRegister({...adminRegister,[name]: value})
    };

    const handleSubmit = (e) =>  {
      console.log("submitted the form");
      e.preventDefault();
      var formError = validate(formValues);

      setFormErrors(formError);
      console.log("Printing the form errors")
      console.log(formError);
      console.log(formErrors);
      setIsSubmit(true);
      // sending the data to the backend
      // try{

        if(Object.keys(formErrors).length === 0){
          console.log("There are no errors we can navigate")
          
        }else{
          console.log("The formErrors is not Empty")
        }

         

          // only send the data to the backend if the form is validated
          // console.log("Sending the data to the backend NOWWWWWWWWWWWWWWWWWWWWWWWWWW");
          // const response = axios.post("http://localhost:3000/login",JSON.stringify({email:formValues.email,password:formValues.password}),{
          //     headers: { 'Content-Type': 'application/json' },
          //     withCredentials: false
          // }).then ( (res) => {

          //   // logging the response from the server
          //   console.log("We got data from the backend")

          //   console.log(res.data);

          //   if(res.data.length < 0){
          //     console.log("We got an error")
          //     setError("Enter the right password or email")
          //   }else if( typeof res.data === 'string'){
          //     console.log(`We got an error ${res.data}`);
          //     // then an error has occured from the api
          //     setError(res.data);
          //   }else{
          //     // check if the user clicked admin or staff
          //     console.log(`The data is fine we can login-------- ${res.data}`);
          //       if( type === "Admin"){
          //         setAdmin(true);
          //         navigate("/staff",{state:{user:res.data}});
          //       }else if(type === "Staff"){
          //         setStaff(true);
          //         navigate("/home",{state:{user:res.data}});
          //       }
              
          //   }

          //   /// navigate to the right page
          //     //check if the person is an admin or not ? (Go to admin ) : (go to staff)
          //   // save the login info into memory

          // }).catch((error) => {
          //   console.log("An error has occurred!!!");
          //   setError(error);
          //   console.log(error)
          // });

       


          // console.log(response);

          // const password = response.data.password;

          // const username = response.data.username;

          // setAuth({username,password});
          // console.log(JSON.stringify(response.data))
          // setUser('');
          // setPwd('');
          // setSuccess(true);

      // }catch(error){
      //   console.log("An error has occurred!!!");
      //     console.log(error)

      // }


    };

    useEffect(() => {
      console.log(formErrors);
      // then there are no errors recorded
      if (Object.keys(formErrors).length === 0 && isSubmit) {
        console.log(formValues);
      }
    }, [formErrors]);

    

    // const handleChange = (e) => {
    //   const { name, value } = e.target;
    //   setUserData({ ...userData, [name]: value });
    // };

    const validate = (values) => {
      console.log("Validating the form")
      console.log(values);
      const errors = {}; 
      const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i; 
      if (!values.email) {
        errors.email = "Email is required!";
      } else if (!regex.test(values.email)) {
        errors.email = "This is not a valid email format!";
      }
      if (!values.password) {
        errors.password = "Password is required";
      } else if (values.password.length < 4) {
        errors.password = "Password must be more than 4 characters";
      } else if (values.password.length > 30) {
        errors.password = "Password cannot exceed more than 30 characters";
      }
      console.log(errors)
      return errors;
    };

    return (
      <div className="flex flex-col ">
      {/* <form onSubmit={handleSubmit}> */}

      <div className="w-full mx-2 flex-1">
          <div className="font-bold h-6 mt-3 text-gray-500 text-xs leading-8 uppercase">
            Surname
          </div>
          <div className="bg-white my-2 p-1 flex border border-gray-200 rounded">
            <input
              onChange={handleChange}
              value={adminRegister.surname}
              name="surname"
              placeholder="Surname"
              className="p-1 px-2 appearance-none outline-none w-full text-gray-800"
            />
          </div>
        </div>


  
        <div className="w-full mx-2 flex-1">
          <div className="font-bold h-6 mt-3 text-gray-500 text-xs leading-8 uppercase">
            Full Names
          </div>
          <div className="bg-white my-2 p-1 flex border border-gray-200 rounded">
            <input
              onChange={handleChange}
              value={adminRegister.name}
              name="name"
              placeholder="Full Names"
              type="text"
              className="p-1 px-2 appearance-none outline-none w-full text-gray-800"
            />
          </div>
        </div>
  
        <div className="w-full mx-2 flex-1">
          <div className="font-bold h-6 mt-3 text-gray-500 text-xs leading-8 uppercase">
            Date of Birth
          </div>
          <div className="bg-white my-2 p-1 flex border border-gray-200 rounded">
            <input
              onChange={handleChange}
              value={adminRegister.dob}
              name="dob"
              placeholder=" Date of Birth"
              type="text"
              className="p-1 px-2 appearance-none outline-none w-full text-gray-800"
            />
          </div>
        </div>
  
        <div className="w-full mx-2 flex-1">
          <div className="font-bold h-6 mt-3 text-gray-500 text-xs leading-8 uppercase">
            Email
          </div>
          <div className="bg-white my-2 p-1 flex border border-gray-200 rounded">
            <input
              onChange={handleChange}
              value={adminRegister.email}
              name="email"
              placeholder=" Email"
              type="text"
              className="p-1 px-2 appearance-none outline-none w-full text-gray-800"

            />
          </div>
        </div>
  
        <div className="w-full mx-2 flex-1">
          <div className="font-bold h-6 mt-3 text-gray-500 text-xs leading-8 uppercase">
            Password
          </div>
          <div className="bg-white my-2 p-1 flex border border-gray-200 rounded">
            <input
              onChange={handleChange}
              value={adminRegister.password}
              name="password"
              placeholder=" Password"
              type="password"
              className="p-1 px-2 appearance-none outline-none w-full text-gray-800"
            />
          </div>
        </div>

        <div className="w-full mx-2 flex-1">
          <div className="font-bold h-6 mt-3 text-gray-500 text-xs leading-8 uppercase">
            Confirm Password
          </div>
          <div className="bg-white my-2 p-1 flex border border-gray-200 rounded">
            <input
              onChange={handleChange}
              value={adminRegister.cPassword}
              name="cPassword"
              placeholder=" Password"
              type="password"
              className="p-1 px-2 appearance-none outline-none w-full text-gray-800"
            />
          </div>
        </div>

        <div className="w-full mx-2 flex-1">
          <div className="font-bold h-6 mt-3 text-gray-500 text-xs leading-8 uppercase">
            Choose your church
          </div>
            <DropDownListComponent id='ddlelement' dataSource={sports} placeholder="Select a church" change={getValue} />
        </div>

        

      {/* </form> */}
      </div>
    );
}

export default PersonalDetails