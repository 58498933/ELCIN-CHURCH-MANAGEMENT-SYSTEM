import React from 'react'

const MemberDetails = () => {
  return (
    <div>MemberDetails</div>
  )
}

export default MemberDetails