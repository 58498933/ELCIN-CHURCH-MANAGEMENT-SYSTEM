import React,{useState,useEffect} from 'react'
// import { useStepperContext } from "../../context/StepperContext";
import { useStateContext } from "../../context/ContextProvider";
// import MembersDetails from './baptism/MembersDetails';
// import { DropDownListComponent } from '@syncfusion/ej2-react-dropdowns';

const PersonalDetails = ({userData,newMember}) => {
  console.log("We received the userData in PersonalDetails ")
  console.log(userData)
  console.log(newMember)
  
  const {memberDetails,setMemberDetails } = useStateContext();


//   surname:"", 
  // name:"", 
  // dob:"", 
  // country:"",
  // idNumber: "" ,
  // birthPlace:""
  const initialValues = { 
    // country:userData.fatherCountry,
    surname: userData !== undefined ? userData.surname : "",
    name: userData !== undefined ? userData.name :"" , 
    dateOfBirth: userData !== undefined ? userData.dateOfBirth : "", 
    idNumber: userData !== undefined ? userData.idNumber : "",
    birthPlace: userData !== undefined ? userData.placeOfBirth : ""};

    const handleChange = (e) => {
      console.log(e);
      const { name, value } = e.target;
      // setFormValues({ ...formValues, [name]: value });
      setMemberDetails({...memberDetails,[name]: value})
    };

    useEffect( () =>{
      console.log("Updated membersDetails in useEffect on Page PersonalDetails")
      if(userData !== undefined){
        setMemberDetails(initialValues)
      }
      
    },[userData])

    return (
      <div className="flex flex-col ">

        <div className="mx-2 w-full flex-1">
          <div className="mt-3 h-6 text-xs font-bold uppercase leading-8 text-gray-500">
            Surname
          </div>
          <div className="my-2 flex rounded border border-gray-200 bg-white p-1">
            <input
              onChange={handleChange}
              value={memberDetails.surname}
              name="surname"
              placeholder="surname"
              className="w-full appearance-none p-1 px-2 text-gray-800 outline-none"
            />
          </div>
        </div>

        <div className="mx-2 w-full flex-1">
          <div className="mt-3 h-6 text-xs font-bold uppercase leading-8 text-gray-500">
            Full Names
          </div>
          <div className="my-2 flex rounded border border-gray-200 bg-white p-1">
            <input
              onChange={handleChange}
              value={memberDetails.name}
              name="name"
              placeholder="Full Name"
              className="w-full appearance-none p-1 px-2 text-gray-800 outline-none"
            />
          </div>
        </div>

        <div className="mx-2 w-full flex-1">
          <div className="mt-3 h-6 text-xs font-bold uppercase leading-8 text-gray-500">
            Date of Birth
          </div>
          <div className="my-2 flex rounded border border-gray-200 bg-white p-1">
            <input
              onChange={handleChange}
              value={memberDetails.dateOfBirth}
              name="dateOfBirth"
              placeholder="DD/MM/YYYY"
              className="w-full appearance-none p-1 px-2 text-gray-800 outline-none"
            />
          </div>
        </div>

        {/* <div className="mx-2 w-full flex-1">
          <div className="mt-3 h-6 text-xs font-bold uppercase leading-8 text-gray-500">
            ID Number
          </div>
          <div className="my-2 flex rounded border border-gray-200 bg-white p-1">
            <input
              onChange={handleChange}
              value={memberDetails.idNumber}
              name="idNumber"
              placeholder="ID Number"
              className="w-full appearance-none p-1 px-2 text-gray-800 outline-none"
            />
          </div>
        </div> */}

        <div className="mx-2 w-full flex-1">
          <div className="mt-3 h-6 text-xs font-bold uppercase leading-8 text-gray-500">
            Place of Birth
          </div>
          <div className="my-2 flex rounded border border-gray-200 bg-white p-1">
            <input
              onChange={handleChange}
              value={memberDetails.birthPlace}
              name="birthPlace"
              placeholder="birth place"
              className="w-full appearance-none p-1 px-2 text-gray-800 outline-none"
            />
          </div>
        </div>
      </div>
    );
}

export default PersonalDetails