import React, { useEffect } from 'react'
// import { useStepperContext } from "../../context/StepperContext";
import { useStateContext } from "../../context/ContextProvider";

const FathersDetails = ({userData}) => {
    // const { userData, setUserData } = useStepperContext();

    console.log("We received the userData in PersonalDetails ")
    console.log(userData)
    
    const { membersFather,setMembersFather } = useStateContext();

    const initialValues = { 

        surname: userData !== undefined ? userData.fatherSurname : "",
        name: userData !== undefined ? userData.fatherName : "", 
        dateOfBirth: userData !== undefined ? userData.fatherDOB : "",
        idNumber: userData !== undefined ? userData.fatherIdNumber : "",
        birthPlace: userData !== undefined ? userData.fatherPlaceOfBirth : "",
        country: userData !== undefined ? userData.fatherCountry : ""};

    const handleChange = (e) => {
      const { name, value } = e.target;
      setMembersFather({...membersFather, [name]: value });
    };

    useEffect( () =>{

      if(userData !== undefined){
        setMembersFather(initialValues)
      }
     
    },[userData])

    return (
      <div className="flex flex-col ">
        <div className="w-full mx-2 flex-1">
          <div className="font-bold h-6 mt-3 text-gray-500 text-xs leading-8 uppercase">
            Surname
          </div>
          <div className="bg-white my-2 p-1 flex border border-gray-200 rounded">
            <input
              onChange={handleChange}
              value={membersFather.surname}
              name="surname"
              placeholder="Surname"
              className="p-1 px-2 appearance-none outline-none w-full text-gray-800"
            />
          </div>
        </div>

        <div className="w-full mx-2 flex-1">
          <div className="font-bold h-6 mt-3 text-gray-500 text-xs leading-8 uppercase">
            Full Names
          </div>
          <div className="bg-white my-2 p-1 flex border border-gray-200 rounded">
            <input
              onChange={handleChange}
              value={membersFather.name}
              name="name"
              placeholder="Full Names"
              type="text"
              className="p-1 px-2 appearance-none outline-none w-full text-gray-800"
            />
          </div>
        </div>

        <div className="w-full mx-2 flex-1">
          <div className="font-bold h-6 mt-3 text-gray-500 text-xs leading-8 uppercase">
            Date of Birth
          </div>
          <div className="bg-white my-2 p-1 flex border border-gray-200 rounded">
            <input
              onChange={handleChange}
              value={membersFather.dateOfBirth}
              name="dateOfBirth"
              placeholder="Date of Birth"
              type="text"
              className="p-1 px-2 appearance-none outline-none w-full text-gray-800"
            />
          </div>
        </div>

        <div className="w-full mx-2 flex-1">
          <div className="font-bold h-6 mt-3 text-gray-500 text-xs leading-8 uppercase">
            Place of Birth
          </div>
          <div className="bg-white my-2 p-1 flex border border-gray-200 rounded">
            <input
              onChange={handleChange}
              value={membersFather.birthPlace}
              name="birthPlace"
              placeholder=" Place of Birth"
              type="text"
              className="p-1 px-2 appearance-none outline-none w-full text-gray-800"
            />
          </div>
        </div>

        <div className="w-full mx-2 flex-1">
          <div className="font-bold h-6 mt-3 text-gray-500 text-xs leading-8 uppercase">
            Country
          </div>
          <div className="bg-white my-2 p-1 flex border border-gray-200 rounded">
            <input
              onChange={handleChange}
              value={membersFather.country}
              name="country"
              placeholder=" Country"
              type="text"
              className="p-1 px-2 appearance-none outline-none w-full text-gray-800"
            />
          </div>
        </div>

        <div className="w-full mx-2 flex-1">
          <div className="font-bold h-6 mt-3 text-gray-500 text-xs leading-8 uppercase">
            Id Number
          </div>
          <div className="bg-white my-2 p-1 flex border border-gray-200 rounded">
            <input
              onChange={handleChange}
              value={membersFather.idNumber}
              name="idNumber"
              placeholder=" ID Number"
              type="text"
              className="p-1 px-2 appearance-none outline-none w-full text-gray-800"
            />
          </div>
        </div>
        
      </div>
    );
}

export default FathersDetails