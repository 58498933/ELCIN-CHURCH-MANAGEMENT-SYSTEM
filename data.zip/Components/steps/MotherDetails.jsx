import React,{useState,useEffect} from 'react'

import { useStateContext } from "../../context/ContextProvider";

const MotherDetails = ({userData,newMember}) => {
  const { membersMother,setMembersMother } = useStateContext();

    const initialValues = {
       surname: userData !== undefined ? userData.motherSurname : "",
       name: userData !== undefined ? userData.motherName : "",
       dob: userData !== undefined ? userData.motherDOB : "", 
       country: userData !== undefined ? userData.motherCountry : "",
       idNumber: userData !== undefined ? userData.motherIdNumber : "",
       birthPlace: userData !== undefined ? userData.motherPlaceOfBirth : ""};

    const initialFormErrors = {};
    // const [formValues, setFormValues] = useState(initialValues);
    // const [formErrors, setFormErrors] = useState(initialFormErrors);
    // const [error,setError] = useState("");
    // const [isSubmit, setIsSubmit] = useState(false);

    useEffect( ()=>{
      if(userData !== undefined) {
        setMembersMother(initialValues)
      }
     
    },[userData])

    const handleChange = (e) => {
      console.log(e);
      const { name, value } = e.target;
      // setFormValues({ ...formValues, [name]: value });
      setMembersMother({...membersMother,[name]: value})
    };

    

  // const handleChange = (e) => {
  //   const { name, value } = e.target;
  //   setUserData({ ...userData, [name]: value });
  // };


  return (
    <div className="flex flex-col ">

    <div className="w-full mx-2 flex-1">
      <div className="font-bold h-6 mt-3 text-gray-500 text-xs leading-8 uppercase">
        Surname
      </div>
      <div className="bg-white my-2 p-1 flex border border-gray-200 rounded">
        <input
          onChange={handleChange}
          value={membersMother.surname}
          name="surname"
          placeholder="Surname"
          className="p-1 px-2 appearance-none outline-none w-full text-gray-800"
        />
      </div>
    </div>

    <div className="w-full mx-2 flex-1">
      <div className="font-bold h-6 mt-3 text-gray-500 text-xs leading-8 uppercase">
        Full Names
      </div>
      <div className="bg-white my-2 p-1 flex border border-gray-200 rounded">
        <input
          onChange={handleChange}
          value={membersMother.name}
          name="name"
          placeholder="Full Names"
          type="text"
          className="p-1 px-2 appearance-none outline-none w-full text-gray-800"
        />
      </div>
    </div>

    <div className="w-full mx-2 flex-1">
      <div className="font-bold h-6 mt-3 text-gray-500 text-xs leading-8 uppercase">
        Date of Birth
      </div>
      <div className="bg-white my-2 p-1 flex border border-gray-200 rounded">
        <input
          onChange={handleChange}
          value={membersMother.dob}
          name="dob"
          placeholder=" Date of Birth"
          type="text"
          className="p-1 px-2 appearance-none outline-none w-full text-gray-800"
        />
      </div>
    </div>

    <div className="w-full mx-2 flex-1">
      <div className="font-bold h-6 mt-3 text-gray-500 text-xs leading-8 uppercase">
        Place of Birth
      </div>
      <div className="bg-white my-2 p-1 flex border border-gray-200 rounded">
        <input
          onChange={handleChange}
          value={membersMother.birthPlace}
          name="birthPlace"
          placeholder=" Place of Birth"
          type="text"
          className="p-1 px-2 appearance-none outline-none w-full text-gray-800"
        />
      </div>
    </div>

    
    <div className="w-full mx-2 flex-1">
      <div className="font-bold h-6 mt-3 text-gray-500 text-xs leading-8 uppercase">
        Id Number
      </div>
      <div className="bg-white my-2 p-1 flex border border-gray-200 rounded">
        <input
          onChange={handleChange}
          value={membersMother.idNumber}
          name="idNumber"
          placeholder=" Place of Birth"
          type="text"
          className="p-1 px-2 appearance-none outline-none w-full text-gray-800"
        />
      </div>
    </div>

    <div className="w-full mx-2 flex-1">
      <div className="font-bold h-6 mt-3 text-gray-500 text-xs leading-8 uppercase">
        Country
      </div>
      <div className="bg-white my-2 p-1 flex border border-gray-200 rounded">
        <input
          onChange={handleChange}
          value={membersMother.country}
          name="country"
          placeholder=" Country"
          type="text"
          className="p-1 px-2 appearance-none outline-none w-full text-gray-800"
        />
      </div>
    </div>
    
  </div>

  );
}

export default MotherDetails