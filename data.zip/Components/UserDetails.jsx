import React from 'react'

const UserDetails = ({FullName,dob,idNumber,fatherFullName,motherFullName,lifeStatus}) => {
  return (
    <div className=' m-2'>

    <h3 className=' font-bold text-xl text-blue-50 mt-2'><span className=' font-extrabold text-2xl text-white'>Full Name : </span> {FullName}</h3>
      <h3 className=' text-xl font-semibold mt-2 text-blue-50  '> <span className='font-extrabold text-2xl'>D.O.B : </span>{ dob}</h3>
      <h3 className=' text-xl font-semibold mt-2 text-blue-50 '> <span className=' font-extrabold text-2xl'>ID : </span>{idNumber}</h3>
    
      <h3 className=' text-xl font-semibold mt-2 text-blue-50'> <span className='font-extrabold text-2xl'>Father's Name: </span>{fatherFullName}</h3>
      <h3 className=' text-xl font-semibold mt-2 text-blue-50'> <span className=' font-extrabold text-2xl'>Mother's Name: </span>{motherFullName}</h3>
      <h3 className=' text-xl font-semibold mt-2 text-blue-50'> <span className=' font-extrabold text-2xl'>Life Status: </span>{lifeStatus}</h3>
    </div>
  )
}

export default UserDetails