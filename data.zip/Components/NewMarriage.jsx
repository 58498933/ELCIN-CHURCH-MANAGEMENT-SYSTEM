import React,{useState} from 'react';
import Stepper from "../Components/Stepper"
import StepperControl from "../Components/StepperControl";
import { UseContextProvider } from "../context/StepperContext";
import { BsArrowLeft } from 'react-icons/bs';

import Church from "../Components/steps/marriage/Church"
import Female from "../Components/steps/marriage/Female"
import Male from "../Components/steps/marriage/Male"
// import ChurchDetails from "../Components/steps/
import Final from "../Components/steps/Final";
import { useLocation ,useNavigate} from 'react-router-dom';
import { useStateContext } from '../context/ContextProvider';
import axios from "axios"

const NewMarriage = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const {churchDetails,marriageSpouse} = useStateContext();


  var location = useLocation();
  var navigate = useNavigate();
  var marriageData = location.state.data;

  // console.log("PRINTING THE RECEIVED DATA")
  // console.log(userData);

  console.log("PRINTING THE MARRIAGE DATA")
  console.log(marriageData)

    const steps = [
      "Spouse Details",
      "Church Details",
      "Complete",
    ];
  
    const displayStep = (step) => {
      switch (step) {
        case 1:
          return  <Female newSpouse={true} />;
        case 2:
          return  <Church />;
        case 3:
            return <Final/>;
        default:
      }
    };
  
    const handleClick = (direction) => {
      let newStep = currentStep;
  
      direction === "next" ? newStep++ : newStep--;
      // check if steps are within bounds
      newStep > 0 && newStep <= steps.length && setCurrentStep(newStep);

      if(currentStep === steps.length - 1)
      {
        console.log("WE GOT ALL THE MARRIAGE DATA, WE CAN SEND IT TO THE BACKEND NOW")  
        console.log(marriageSpouse)
        console.log(churchDetails) 

        var data = {
          bishopName:churchDetails.bishopName,
          churchAddress:churchDetails.churchAddress,
          churchName:churchDetails.churchName,
          dateOfMarriage:churchDetails.dateOfMarriage,
          marriagePlace: churchDetails.marriagePlace,
          spouseAddress:marriageSpouse.address,
          spouseFatherName:marriageSpouse.fatherName,
          spouseGender: marriageSpouse.sex,
          idNumber:marriageData.idNumber,
          spouseIdNumber:marriageSpouse.idNumber,
          spouseMotherName:marriageSpouse.motherName,
          spouseName:marriageSpouse.name,
          spouseSurname:marriageSpouse.surname,
          spouseTelephone:marriageSpouse.telephone}


          console.log("PRINTING THE FINAL DATA");
          console.log(data);
  
          sendData(data);

      }

    };

    const sendData = (data) =>{

      const response = axios.post('http://localhost:3000/newMarriage/',data).then((res) =>{
        // 
        if(res.status === 200){
          console.log(" WE HAVE SUCCESSFULLY UPDATED THE DATA")
          console.log(res)
        }else{
          console.log("AN ERROR HAS OCCURED, WE DID NOT UPDATE THE RECORD")
          console.log(res)
        }
      }).catch( (error) =>{
        console.log(error);
      })

    }
    const nav = () => {
      navigate(-1)
    }
  
    return (
      <div className=''>
        <div className=' float-left m-2'>
                  <button type='button' onClick={nav}  style={{ color:'#03C9D7',backgroundColor:'#e5fafb'}} className="text-2xl opacity-0.9 p-4 hover:drop-shadow-xl rounded-lg">
                    <BsArrowLeft />
                  </button>
                </div>
     <div className="mx-auto rounded-2xl pb-2 shadow-xl md:w-1/2 border-2 mt-5">
        {/* Stepper */}
        <div className="horizontal container mt-5 ">
          <Stepper steps={steps} currentStep={currentStep} />
  
          <div className="my-10 p-10 ">
            <UseContextProvider>{displayStep(currentStep)}</UseContextProvider>
          </div>
        </div>
  
        {/* navigation button */}
        {currentStep !== steps.length && (
          <StepperControl
            handleClick={handleClick}
            currentStep={currentStep}
            steps={steps}
          />
        )}
      </div>
      </div>

    );  
}

export default NewMarriage