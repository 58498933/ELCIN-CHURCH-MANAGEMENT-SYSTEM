import React,{useState,useEffect} from 'react'

import { useNavigate } from 'react-router-dom';

import Stepper from "../Components/Stepper"
import StepperControl from "../Components/StepperControl";
import { UseContextProvider } from "../context/StepperContext";

import MembersDetails from "../Components/steps/baptism/MembersDetails"
import FathersDetails from "../Components/steps/baptism/FathersDetails"
import MotherDetails from "../Components/steps/baptism/MothersDetails"
import GodParent from "../Components/steps/baptism/GodParentsDetails"
import Final from "../Components/steps/Final";
import { useLocation } from 'react-router-dom';
import axios from 'axios';

// Receives the userdata from other profile page

const EditBaptism = () => {
      
  var navigate = useNavigate();
  var location = useLocation();
  var baptismData = location.state.baptismData;

  console.log("We received the baptism data")
  console.log(baptismData);

  // useEffect( () =>{
  //   const response = 
  // },[userData])



  const initialValues = { baptismDate: baptismData.dateOfBaptism, baptismPlace: baptismData.placeOfBaptism ,churchName:baptismData.churchName,churchAddress:baptismData.churchAddress,pastorsName:baptismData.pastorName};
  const initialFormErrors = {};
  const [formValues, setFormValues] = useState(initialValues);
  const [formErrors, setFormErrors] = useState(initialFormErrors);
  // const [error,setError] = useState("");
  const [isSubmit, setIsSubmit] = useState(false);

  // const {setAdmin} = useStateContext()

  const handleChange = (e) => {
      console.log(e);
      const { name, value } = e.target;
      setFormValues({ ...formValues, [name]: value });
    };

    const handleSubmit = (e) =>  {
      console.log("submitted the form");
      e.preventDefault();
      var formError = validate(formValues);

      setFormErrors(formError);
      console.log("Printing the form errors")
      console.log(formError);
      console.log(formErrors);
      setIsSubmit(true);

//       churchAddress: "ohalushu Ongha"
// ​
// churchName: "Ohalushu"
// ​
// dateOfBaptism: "10 Aug 2020"
// ​
// pastorName: ""
// ​
// placeOfBaptism: "ongha

      const response = axios.put(`http://localhost:3000/updateBaptism/${baptismData.IdNumber}`,{
        churchAddress:formValues.churchAddress,
        churchName:formValues.churchName,
        dateOfBaptism:formValues.dateOfBaptism,
        pastorName:formValues.pastorsName
    }).then( (res) =>{
      if(res.status === 200){
        console.log(res)
        navigate(-1);
      }else{
        console.log("An error has occurred!");
      }
      }).catch( (error) =>{
        console.log(`An error has occured ${error}`)
      })
    }


  const validate = (values) => {
      console.log("Validating the form")
      console.log(values);
      const errors = {}; 
      const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i; 
      if (!values.email) {
        errors.email = "Email is required!";
      } else if (!regex.test(values.email)) {
        errors.email = "This is not a valid email format!";
      }
      if (!values.password) {
        errors.password = "Password is required";
      } else if (values.password.length < 4) {
        errors.password = "Password must be more than 4 characters";
      } else if (values.password.length > 30) {
        errors.password = "Password cannot exceed more than 30 characters";
      }
      console.log(errors)
      return errors;
    };


return (
  
<div className='flex flex-col justify-center'>
  <form className='max-w-[400px] w-full mx-auto  p-4 rounded-lg' onSubmit={handleSubmit}>
      <h2 className='text-4xl font-bold text-center py-6'> Update Baptism Details</h2>
      <div className='flex flex-col py-2'>
          <label>Place of Baptism</label>
          <input className='border rounded-md p-2 ' type="text" 
           name='baptismPlace'
           placeholder='Place of Baptism'
           value={formValues.baptismPlace}
           onChange={handleChange}
          />
      </div>
      <p>{formErrors.email}</p>

      <div className='flex flex-col py-2'>
          <label>Date of Baptism</label>
          <input className='border p-2 rounded-md' type="text" 
              name='baptismDate'
              placeholder='Date of Baptism'
              value={formValues.baptismDate}
              onChange={handleChange}
          />
      </div>

      {/* <p>{formErrors.password}</p> */}

      <div className='flex flex-col py-2'>
          <label>Church Name</label>
          <input className='border p-2 rounded-md' type="text" 
              name='churchName'
              placeholder="Church's Name"
              value={formValues.churchName}
              onChange={handleChange}
          />
      </div>

      <div className='flex flex-col py-2'>
          <label>Church Address</label>
          <input className='border p-2 rounded-md' type="text" 
              name='churchAddress'
              placeholder='Church Address'
              value={formValues.churchAddress}
              onChange={handleChange}
          />
      </div>

      <div className='flex flex-col py-2'>
          <label>Pastor's Name</label>
          <input className='border p-2 rounded-md' type="text" 
              name='pastorsName'
              placeholder="pastor's Name"
              value={formValues.pastorsName}
              onChange={handleChange}
          />
      </div>

      <button className='border w-full my-5 rounded-lg py-2 hover:bg-indigo-500 text-white' >Update</button>
  </form>
</div>
)
}

export default EditBaptism