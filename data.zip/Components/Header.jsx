/* eslint-disable */
import React from 'react'
import { AiOutlineLogin } from 'react-icons/ai';

const Header = ({category,title}) => {
  return (
    <div className='mb-10'>
   
        {/* <button type='button' onClick={null}  style={{ color:'#03C9D7',backgroundColor:'#E5FAFB'}} className="opacity-0.9 p-4 hover:drop-shadow-xl float-right">
         <AiOutlineLogin />
        </button> */}
   
      <p className="float-left text-3xl font-extrabold tracking-tight text-slate-900">{title}</p>
    </div>
  )
}

export default Header