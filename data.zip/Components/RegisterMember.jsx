import React,{useState} from 'react'
import Stepper from "../Components/Stepper"
import StepperControl from "../Components/StepperControl";
import { UseContextProvider } from "../context/StepperContext";
import axios from "axios"


import { useNavigate } from 'react-router-dom';

import { DropDownListComponent } from '@syncfusion/ej2-react-dropdowns';

const RegisterMember = () => {
  
  var navigate = useNavigate();
  const initialValues = { surname: "", name: "" ,email:"",password:"",confirmPassword:"", idNumber:""};
  const initialFormErrors = {};
  var allErrors = {};
  const [formValues, setFormValues] = useState(initialValues);
  const [formErrors, setFormErrors] = useState(initialFormErrors);
  const [success , setSuccess] = useState("");
  

  // const [error,setError] = useState("");
  const [isSubmit, setIsSubmit] = useState(false);

  const handleChange = (e) => {
      console.log(e);
      const { name, value } = e.target;
      setFormValues({ ...formValues, [name]: value });
    };

    const handleSubmit = (e) =>  {
      console.log("submitted the form");
      e.preventDefault();
      var formError = validate(formValues);

      setFormErrors(formError);
      console.log("Printing the form errors")
      console.log(formError);
      console.log(formErrors);
      setIsSubmit(true);


      // Meaning we have no errors?
      if(Object.keys(allErrors).length === 0){

        try{
        const response = axios.put("http://localhost:3000/registerMember",JSON.stringify({idNumber:formValues.idNumber,password:formValues.password}),{
            headers: { 'Content-Type': 'application/json' },
            withCredentials: false
        }).then((res) =>{
          console.log("We got back a result from the backend")
          console.log(res);
          if(res.status === 200 && res.data.changedRows > 0){
            // We can navigate back
            setSuccess("Account created Successfully")
            navigate(-1);
            
          }else{
            setSuccess("The ID Number is not in the system");
          }
        }).catch( (err) => {
          console.log("An error has occured!")
          console.log(err)
        })
        }catch(e){
          console.log(`An errror has occurred ${e}`)
        }
      }else{
        console.log("There are form errors");
      }
    };


  const validate = (values) => {
      console.log("Validating the form")
      console.log(values);
      const errors = {}; 
      // const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i; 

      if (!values.password) {
        errors.password = "Password is required";
      } else if (values.password.length < 4) {
        errors.password = "Password must be more than 4 characters";
      } else if (values.password.length > 30) {
        errors.password = "Password cannot exceed more than 30 characters";
      } 
 
      if(values.password !== values.confirmPassword){
        errors.password = "The Entered passwords are not matching"
      }

      if(!values.idNumber){
        errors.idNumber = "Please Enter your Id Number"
      }
      else if(values.idNumber.length < 3){
        errors.idNumber = "Id Number should be more"
      }
      console.log(errors)
      allErrors = errors;
      return errors;
    };
    
return ( 
<div className='flex flex-col justify-center text-white'>
  <form className='max-w-[400px] w-full mx-auto  p-4 rounded-lg' onSubmit={handleSubmit}>
      <h2 className='text-4xl font-bold text-center py-6'> Create a new Account</h2>
      <div className='flex flex-col py-2'>
          <label>Id Number</label>
          <label className=' text-xs text-gray-600'>DD/MM/YYYY/NameInitials</label>
          <input className='border rounded-md p-2 text-black' type="text" 
           name='idNumber'
           placeholder='example 20081999AE'
           value={formValues.idNumber}
           onChange={handleChange}
          />
      </div>
      <p className=' text-red-700'>{formErrors.idNumber}</p>

      <div className='flex flex-col py-2'>
          <label>Password</label>
          <input className='border p-2 rounded-md text-black' type="text" 
              name='password'
              placeholder="Password"
              value={formValues.password}
              onChange={handleChange}
          />
      </div>
      <p className=' text-red-700'>{formErrors.password}</p>

      <div className='flex flex-col py-2'>
          <label>Confirm Password</label>
          <input className='border p-2 rounded-md text-black' type="text" 
              name='confirmPassword'
              placeholder="Confirm Password"
              value={formValues.confirmPassword}
              onChange={handleChange}
          />
      </div>
      <p className=' text-red-700'>{formErrors.password}</p>
      <p className=' text-red-700'>{success}</p>

      <button className='border w-full my-5 rounded-lg py-2 hover:bg-indigo-500 text-white' >Create Account</button>
  </form>
</div>
);
}

export default RegisterMember