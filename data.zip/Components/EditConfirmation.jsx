import axios from 'axios';
import React,{useState} from 'react'
import { useNavigate } from 'react-router-dom';
import { useLocation } from 'react-router-dom';


// import Stepper from "../Components/Stepper"
// import StepperControl from "../Components/StepperControl";
// import { UseContextProvider } from "../context/StepperContext";

// import MembersDetails from "../Components/steps/confirmation/MembersDetails"
// import FathersDetails from "../Components/steps/confirmation/FathersDetails"
// import MotherDetails from "../Components/steps/confirmation/MothersDetails"
// import ChurchDetails from "../Components/steps/confirmation/ChurchDetails"
// import Final from "../Components/steps/Final";

const EditConfirmation = () => {
  var navigate = useNavigate();
  var location = useLocation();

  var confirmationData = location.state.confirmationData;
  console.log("Printing the conformation data!!!!!");
  console.log(confirmationData);

//   churchAddress: "ohalushu Ongha"
// ​
// churchName: "Ohalushu"
// ​
// dateOfConfirmation: "10 Aug 2020"
// ​
// idNumber: "5555"
// ​
// pastorName: "Erikyyy"
// ​
// placeOfConfirmation: "Ongha"

  const initialValues = { 
    confirmationDate: confirmationData.dateOfConfirmation, 
    confirmationPlace: confirmationData.placeOfConfirmation ,
    churchName:confirmationData.churchName,
    churchAddress:confirmationData.churchAddress,
    priestName: confirmationData.pastorName};

  const initialFormErrors = {};
  const [formValues, setFormValues] = useState(initialValues);
  const [formErrors, setFormErrors] = useState(initialFormErrors);
  // const [error,setError] = useState("");
  // const [isSubmit, setIsSubmit] = useState(false);

  // const {setAdmin} = useStateContext()

  const handleChange = (e) => {
      console.log(e);
      const { name, value } = e.target;
      setFormValues({ ...formValues, [name]: value });
    };

    const handleSubmit = (e) =>  {
      console.log("submitted the form");
      e.preventDefault();
      var formError = validate(formValues);

      setFormErrors(formError);
      console.log("Printing the form errors")
      console.log(formError);
      console.log(formErrors);

//   churchAddress: "ohalushu Ongha"
// ​
// churchName: "Ohalushu"
// ​
// dateOfConfirmation: "10 Aug 2020"
// ​
// idNumber: "5555"
// ​
// pastorName: "Erikyyy"
// ​
// placeOfConfirmation: "Ongha"

      const resposne = axios.put(`http://localhost:3000/updateConfirmation/${confirmationData.idNumber}`,{
        churchAddress:formValues.churchAddress,
        churchName:formValues.churchName,
        dateOfConfirmation:formValues.confirmationDate,
        pastorName:formValues.priestName,
        placeOfConfirmation:formValues.confirmationPlace
      }).then( (res) =>{
        if(res.status === 200){
          // Navigate back
          navigate(-1);
        }else{
          console.log("An error has occured")
        }
      }).catch( () =>{

      })

    };


  const validate = (values) => {
      console.log("Validating the form")
      console.log(values);
      const errors = {}; 
      const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i; 
      if (!values.email) {
        errors.email = "Email is required!";
      } else if (!regex.test(values.email)) {
        errors.email = "This is not a valid email format!";
      }
      if (!values.password) {
        errors.password = "Password is required";
      } else if (values.password.length < 4) {
        errors.password = "Password must be more than 4 characters";
      } else if (values.password.length > 30) {
        errors.password = "Password cannot exceed more than 30 characters";
      }
      console.log(errors)
      return errors;
    };


return (
  
<div className='flex flex-col justify-center'>
  <form className='max-w-[400px] w-full mx-auto  p-4 rounded-lg' onSubmit={handleSubmit}>
      <h2 className='text-4xl font-bold text-center py-6'> Update Confirmation Details</h2>
      <div className='flex flex-col py-2'>
          <label>Place of Baptism</label>
          <input className='border rounded-md p-2 ' type="text" 
           name='baptismPlace'
           placeholder='Place of Baptism'
           value={formValues.confirmationPlace}
           onChange={handleChange}
          />
      </div>
      <p>{formErrors.email}</p>

      <div className='flex flex-col py-2'>
          <label>Date of Baptism</label>
          <input className='border p-2 rounded-md' type="text" 
              name='baptismDate'
              placeholder='Date of Baptism'
              value={formValues.confirmationDate}
              onChange={handleChange}
          />
      </div>

      {/* <p>{formErrors.password}</p> */}

      <div className='flex flex-col py-2'>
          <label>Church Name</label>
          <input className='border p-2 rounded-md' type="text" 
              name='churchName'
              placeholder="Church's Name"
              value={formValues.churchName}
              onChange={handleChange}
          />
      </div>

      <div className='flex flex-col py-2'>
          <label>Church Address</label>
          <input className='border p-2 rounded-md' type="text" 
              name='churchAddress'
              placeholder='Church Address'
              value={formValues.churchAddress}
              onChange={handleChange}
          />
      </div>

      <div className='flex flex-col py-2'>
          <label>Pastor's Name</label>
          <input className='border p-2 rounded-md' type="text" 
              name='pastorsName'
              placeholder="pastor's Name"
              value={formValues.priestName}
              onChange={handleChange}
          />
      </div>

      <button className='border w-full my-5 rounded-lg py-2 hover:bg-indigo-500 text-white' >Update</button>
  </form>
</div>
)
}

export default EditConfirmation