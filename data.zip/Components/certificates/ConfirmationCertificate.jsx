import React from 'react'
import {
    Document,
    Page,
    Image,
    Text,
    View,
    StyleSheet,
    PDFViewer,
  } from "@react-pdf/renderer";

  import { useLocation } from 'react-router-dom';
  import ELCIN from "C:/Users/Erick Abraham/Documents/Eacelab/Cms/client/src/assets/elcin.jpg"
// Create styles
const styles = StyleSheet.create({
  body: {
    paddingTop: 35,
    paddingBottom: 65,
    paddingHorizontal: 35,
    border:10,
    borderColor:'#1e293b',
    borderTopRightRadius: 30,
    borderTopLeftRadius:30,
    borderBottomRightRadius:30,
    borderBottomLeftRadius:30
  },
  title: {
    fontSize: 24,
    textAlign: 'center',
    // fontFamily: 'Oswald'
  },
  author: {
    fontSize: 12,
    textAlign: 'center',
    marginBottom: 40,
    letterSpacing:3,
    
  },
  subtitle: {
    fontSize: 18,
    margin: 12,
    // fontFamily: 'Oswald',
    textAlign: 'center',
    borderBottom:1
  },
  text: {
    margin: 12,
    fontSize: 18,
    // fontFamily: 'Times-Roman',
    textAlign: 'center',
    letterSpacing:2,
    
    
  },
  image: {
    // marginVertical: 15,
    marginVertical: 15,
    marginHorizontal: 100,
    // width: 200,
    height: 200,
  },
  header: {
    fontSize: 12,
    marginBottom: 20,
    textAlign: 'center',
    color: 'grey',
  },
  viewer: {
        width: window.innerWidth, //the pdf viewer will take up all of the width and height
        height: window.innerHeight,
  }
});

const ConfirmationCertificate = () => {
    var location = useLocation()
    var userData = location.state.userData;
    var confirmationData = location.state.confirmationData
    console.log("Printing the received data: ")
    
    console.log(userData)
    console.log(confirmationData)

    return (
      <PDFViewer style={styles.viewer}>
        {/* Start of the document*/}
        <Document>
      <Page size="A4" style={styles.body}>
      <Image
          style={styles.image}
          src={ELCIN}
        />
        <Text style={styles.title}>Certificate of Confirmation</Text>
        <Text style={styles.author}>This certify that</Text>
        <Text style={styles.subtitle}>
          {userData.name} {userData.surname}
        </Text>
        <Text style={styles.header}>
        Full Names
      </Text>
        <Text style={styles.text}>
           Was Confirmed  in the church of ELCIN
        </Text>
        <Text style={styles.subtitle}>
         On the date:
        </Text>
        <Text style={styles.text}>
          {confirmationData.dateOfConfirmation}
        </Text>
        <Text style={styles.subtitle}>
          By Pastor:  {confirmationData.pastorName}
        </Text>
       
      </Page>
    </Document>
      </PDFViewer>
    )
}

export default ConfirmationCertificate