import React from 'react'
import {
  Document,
  Page,
  Image,
  Text,
  View,
  StyleSheet,
  PDFViewer,
} from "@react-pdf/renderer";
import { useLocation } from 'react-router-dom';
import ELCIN from "C:/Users/Erick Abraham/Documents/Eacelab/Cms/client/src/assets/elcin.jpg"
//C:/Users/Erick Abraham/Documents/Eacelab/Cms/client/src/assets/elcin.jpg

const styles = StyleSheet.create({
  body: {
    paddingTop: 35,
    paddingBottom: 65,
    paddingHorizontal: 35,
    border:10,
    borderColor:'#1e293b',
    borderTopRightRadius: 30,
    borderTopLeftRadius:30,
    borderBottomRightRadius:30,
    borderBottomLeftRadius:30
  },
  title: {
    fontSize: 24,
    textAlign: 'center',
    // fontFamily: 'Oswald'
  },
  author: {
    fontSize: 12,
    textAlign: 'center',
    marginBottom: 40,
    letterSpacing:3,
    
  },
  subtitle: {
    fontSize: 18,
    margin: 12,
    // fontFamily: 'Oswald',
    textAlign: 'center',
    borderBottom:1
  },
  text: {
    margin: 12,
    fontSize: 18,
    // fontFamily: 'Times-Roman',
    textAlign: 'center',
    letterSpacing:2,
    
    
  },
  image: {
    // marginVertical: 15,
    marginVertical: 15,
    marginHorizontal: 100,
    // width: 200,
    height: 200,
  },
  header: {
    fontSize: 12,
    marginBottom: 20,
    textAlign: 'center',
    color: 'grey',
  },
//     position: 'absolute',
//     fontSize: 12,
//     bottom: 30,
//     left: 0,
//     right: 0,
//     textAlign: 'center',
//     color: 'grey',
//   },
  viewer: {
        width: window.innerWidth, //the pdf viewer will take up all of the width and height
        height: window.innerHeight,
  }
});



// const font = Font.register({
//   family: 'Oswald',
//   src: 'https://fonts.gstatic.com/s/oswald/v13/Y_TKV6o8WovbUd3m_X9aAA.ttf'
// });
  


const Certificate = () => {
  var location = useLocation()
  var userData = location.state.userData;
  var baptismData = location.state.baptismData;
  console.log("Printing the received data: ")

  console.log(userData)
  console.log(baptismData)
  return (
    <PDFViewer style={styles.viewer}>
      {/* Start of the document*/}
      <Document>
      <Page size="A4" style={styles.body}>
      <Image
        style={styles.image}
        src={ELCIN}
      />
        <Text style={styles.title}>Certificate of Baptism</Text>
        <Text style={styles.author}>This certify that</Text>
        <Text style={styles.subtitle}>
          {userData.name} {userData.surname}
        </Text>
        <Text style={styles.header}>
        Full Names
      </Text>
        <Text style={styles.text}>
          Was Baptised in the name of the Father, the Son and the holy spirit
        </Text>
        <Text style={styles.text}>
          On the date:
        </Text>
        <Text style={styles.subtitle}>
          {baptismData.dateOfBaptism}
        </Text>
        <Text style={styles.text}>
			    At the holy church of:
      </Text>
      <Text style={styles.subtitle}>
			    ELCIN Ohalushu
      </Text>
        <Text style={styles.text}>
        By Pastor:
        </Text>
        <Text style={styles.subtitle}>
          {baptismData.pastorName}
        </Text>
    </Page>
  </Document>
    </PDFViewer>
  )
}

export default Certificate