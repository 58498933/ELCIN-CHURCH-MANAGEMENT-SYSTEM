import React,{useState} from 'react'
import {
    Document,
    Page,
    Image,
    Text,
    View,
    StyleSheet,
    PDFViewer,
  } from "@react-pdf/renderer";
  import { useLocation } from 'react-router-dom';
  import ELCIN from "C:/Users/Erick Abraham/Documents/Eacelab/Cms/client/src/assets/elcin.jpg"
// Create styles
const styles = StyleSheet.create({
  body: {
    paddingTop: 35,
    paddingBottom: 65,
    paddingHorizontal: 35,
    border:10,
    borderColor:'#1e293b',
    borderTopRightRadius: 30,
    borderTopLeftRadius:30,
    borderBottomRightRadius:30,
    borderBottomLeftRadius:30
  },
  title: {
    fontSize: 20,
    textAlign: 'center',
    // fontFamily: 'Oswald'
  },
  author: {
    fontSize: 12,
    textAlign: 'center',
    marginBottom: 30,
    letterSpacing:3,
    
  },
  subtitle: {
    fontSize: 15,
    margin: 10,
    // fontFamily: 'Oswald',
    textAlign: 'center',
    borderBottom:1
  },
  text: {
    margin: 10,
    fontSize: 14,
    // fontFamily: 'Times-Roman',
    textAlign: 'center',
    letterSpacing:2,
    
    
  },
  image: {
    // marginVertical: 15,
    marginVertical: 15,
    marginHorizontal: 100,
    // width: 200,
    height: 200,
  },
  header: {
    fontSize: 10,
    marginBottom: 10,
    textAlign: 'center',
    color: 'grey',
  },
  viewer: {
        width: window.innerWidth, //the pdf viewer will take up all of the width and height
        height: window.innerHeight,
  }
});

const MarriageCertificate = () => {
    var location = useLocation()
    var userData = location.state.userData;
    var marriageData = location.state.marriageData;

    console.log("Printing the received data: ")
    console.log(userData)


    return (
      <PDFViewer style={styles.viewer}>
        {/* Start of the document*/}
        <Document>
      <Page size="A4" style={styles.body}>
              <Image
          style={styles.image}
          src={ELCIN}
        />
        <Text style={styles.title}>Certificate of Marriage</Text>
        <Text style={styles.author}>This certify that</Text>
        <Text style={styles.subtitle}>
          {userData.name} {userData.surname}
        </Text>
        <Text style={styles.text}>
          and
        </Text>

        <Text style={styles.subtitle}>
          {marriageData.spouseName} {marriageData.spouseSurname}
        </Text>

        <Text style={styles.text}>
          Where lawfully Married
        </Text>
        <Text style={styles.text}>
         On the date:
        </Text>
        <Text style={styles.subtitle}>
          {marriageData.dateOfMarriage}
        </Text>
        <Text style={styles.text}>
          At the Venue: 
        </Text>
        <Text style={styles.subtitle}>
         {marriageData.marriagePlace}
        </Text>
        
        <Text style={styles.text}>
          By Pastor: 
        </Text>

        <Text style={styles.subtitle}>
         {marriageData.bishopName}
        </Text>

      </Page>
    </Document>
      </PDFViewer>
    )
}

export default MarriageCertificate