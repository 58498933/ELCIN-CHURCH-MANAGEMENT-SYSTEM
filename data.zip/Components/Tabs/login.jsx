import React,{useState} from 'react';
import Admin from "../AllTabs/admin";
import Member from "../AllTabs/member";
import trees from "C:/Users/Erick Abraham/Documents/Eacelab/Cms/client/src/assets/trees.jpg"

const Login = () => {
  const [activeTab,setActivetab] = useState("Admin");


  // method for handling switch functionality
  const handleMember = () => {
    setActivetab("Member");
  }
  // method for handling admin switch functionality
  const handleAdmin = () => {
    setActivetab("Admin");
  }

  return (
    <div className="Tab border-2">
      {/* Tab nav */}
      <ul className="navi ">
        <li className={activeTab === "Admin" ? "active":""} onClick={handleAdmin}>Admin
        
        </li>
        <li className={activeTab === "Member" ? "active":""} onClick={handleMember}>Member</li>
      </ul>
      <div className="outlet">
    
        {/* content will be shown here */}
        {activeTab === "Admin" ? <Admin admin={true}/>: <Admin admin={false}/>}
      
      </div>
    </div>
  )
}

export default Login