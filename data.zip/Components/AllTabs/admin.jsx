import React,{useState,useEffect} from 'react'
import  { useNavigate } from 'react-router-dom'
import { useStateContext } from '../../context/ContextProvider'
import axios from "axios";

const Admin = ({admin}) => {

  console.log(`Printing The Received Var of admin ${admin}`)
    
    var navigate = useNavigate();
    const initialValues = {email: "", password: "",idNumber:"" };
    const initialFormErrors = {};
    var allErrors = {};
    const [formValues, setFormValues] = useState(initialValues);
    const [formErrors, setFormErrors] = useState(initialFormErrors);
    const [error,setError] = useState("");
    const [isSubmit, setIsSubmit] = useState(false);

    const {setAdmin} = useStateContext()

    const handleChange = (e) => {
        console.log(e);
        const { name, value } = e.target;
        setError("");
        setFormValues({ ...formValues, [name]: value });
      };

      const handleSubmit = (e) =>  {
        console.log("submitted the form");
        e.preventDefault();

        validate(formValues);

        // setFormErrors(validate(formValues));
        console.log("Printing the form errors")
      
        console.log(formErrors);
        setIsSubmit(true);
        // sending the data to the backend
     
        if(Object.keys(allErrors).length === 0){
          console.log("The form has no errors");
          console.log(formErrors)
          console.log(`The formErrors length ${Object.keys(formErrors).length}`)
          if(admin){
            // Then we can login as an Admin
            const response = axios.post("http://localhost:3000/login",JSON.stringify({email:formValues.email,password:formValues.password}),{
              headers: { 'Content-Type': 'application/json' },
               withCredentials: false
           }).then( (res) => {

            if(res.data.length < 0){
              console.log("We got an error")
              setError("Enter the right password or email")
            }else if( typeof res.data === 'string'){
              console.log(`We got an error ${res.data}`);
              // then an error has occured from the api
              setError(res.data);
            }else{
              // check if the user clicked admin or staff
              console.log(`The data is fine we can login-------- ${res.data}`);
              console.log(res.data)
             
                  setAdmin(true);
                  navigateToAdmin (res.data);
              
            }
           }).catch( (e) =>{
            console.log(`an error has occured ${e}`)
           })

          }else{
            console.log(`Admin is ${admin}: Sending the data to MemberLogin`)
            const response = axios.post("http://localhost:3000/memberLogin",JSON.stringify({idNumber:formValues.idNumber,password:formValues.password}),{
              headers: { 'Content-Type': 'application/json' },
               withCredentials: false
           }).then( (res) => {

            if(res.data.length < 0){
              console.log("We got an error")
              setError("Enter the right password or Id Number")
            }else if( typeof res.data === 'string'){
              console.log(`An error has occured ${res.data}`);
              // then an error has occured from the api
              setError(res.data);
            }else{
              // check if the user clicked admin or staff
              console.log(`The data is fine we can login-------- ${res.data}`);
                  navigateToMember(res.data);
            }
           }).catch( (e) =>{
            console.log(`an error has occured ${e}`)
           })

          }
        }else{
          console.log("The form has error");
          console.log(formErrors);
          console.log(`The formErrors length ${Object.keys(formErrors).length}`)
        }
      }

      const validate = (values) => {
        console.log("Validating the form")
        console.log(values);
        // form errors
        const errors = {}; 
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i; 

        if(admin){
          if (!values.email) {
            errors.email = "Email is required!";
          } 
          else if (!regex.test(values.email)) {
            errors.email = "This is not a valid email format!";
                }
        }
        else{
          if(!values.idNumber){
            errors.idNumber = "Please enter an Id Number";
            }
        }

        if (!values.password) {
          errors.password = "Password is required";
        } else if (values.password.length < 4) {
          errors.password = "Password must be more than 4 characters";
        }

        console.log(errors)
        setFormErrors(errors);
        allErrors = errors;
        console.log("Just called setFormErrors method")
        console.log(formErrors);
        return errors;
      };

      


    // navigate to 
    const navigateToRegister = () => {
        console.log("Clicked");
        if(admin === true){
            navigate("/register",{state:{type:"Admin"}});
        }else{
            navigate("/register",{state:{type:"Member"}});
        }
        
        
    }

    const navigateToAdmin = (userData) => {
        // for navigating to the admin page and sending the login data there
        setAdmin(true);
        navigate("/members",{state:{userData:userData}});
    }

    const navigateToMember = (userData) => {
        // for navigating to the member page
        navigate("/member",{state:{userData:userData}});
    }



  return ( 
  <div className='flex flex-col justify-center'>

  {/* {Object.keys(formErrors).length === 0 && isSubmit ? (
      <div className="ui message success">Form validate successfully</div>
    ) : (
      <pre>{JSON.stringify(formValues, undefined, 2)}</pre>
    )} */}

    <form className='max-w-[400px] w-full mx-auto  p-4 rounded-lg' onSubmit={handleSubmit}>
        <h2 className='text-4xl font-bold text-center py-6'>Login as {admin ? "an Admin" : "a Member"}</h2>

        <div className='flex flex-col py-2'>
            <label>{admin ? "Email" : "ID Number"}</label>
            <input className='border rounded-md p-2 text-black' type="text" 
             name= {admin ? "email" : "idNumber"}
             placeholder={admin ? "Email" : "Id Number"}
             value={admin ? formValues.email : formValues.idNumber}
             onChange={handleChange}
            />
        </div>
        <p className=' text-red-700'>{formErrors.email || formErrors.idNumber} </p>
        <div className='flex flex-col py-2'>
            <label>Password</label>
            <input className='border p-2 rounded-md text-black' type="password"
                name='password'
                placeholder='Enter your Password'
                value={formValues.password}
                onChange={handleChange}
            />
        </div>
        <p className=' text-red-700'>{formErrors.password}</p>
        <p className=' text-red-700'>{error}</p>
        <button className='border w-full my-5 rounded-lg py-2 hover:bg-indigo-500 text-white' >Sign In</button>
        <div className='flex justify-between'>
            <p className='flex items-center'><input className='mr-2' type="checkbox" /> Remember Me</p>
            <p onClick= {navigateToRegister} className='cursor-pointer'>Create an account</p>
        </div>
    </form>
</div>
          )

}

export default Admin