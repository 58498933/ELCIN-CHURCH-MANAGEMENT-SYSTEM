import React from 'react'
import { useNavigate } from 'react-router-dom';
import { useStateContext } from '../../context/ContextProvider';
const Member = () => {
    var navigate = useNavigate();
    const {setMember} = useStateContext()

    const nav = ()=>{
        navigate("/register",{state:{type:"Member"}})
    }

    const navToMember = () =>{

        // navigate to the members home page
        setMember(true);
        navigate("/member",)
    }

  return (

    <div className='flex flex-col justify-center'>
    <form className='max-w-[400px] w-full mx-auto  p-4 rounded-lg'>
        <h2 className='text-4xl font-bold text-center py-6'>Login as a Member</h2>
        <div className='flex flex-col py-2'>
            <label>Username</label>
            <input className='border rounded-md p-2 ' type="text" />
        </div>
        <div className='flex flex-col py-2'>
            <label>Password</label>
            <input className='border p-2 rounded-md' type="password" />
        </div>
        <button className='border w-full my-5 rounded-lg py-2 hover:bg-indigo-500 text-white' onClick={navToMember}>Sign In</button>
        <div className='flex justify-between'>
            <p className='flex items-center'><input className='mr-2' type="checkbox" /> Remember Me</p>
            <p className='cursor-pointer' onClick={nav}>Create an account</p>
        </div>
    </form>
</div>
  )
}

export default Member;