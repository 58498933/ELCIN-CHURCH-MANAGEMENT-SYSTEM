import React from 'react'
import { FaCertificate } from 'react-icons/fa';
import { FiEdit } from 'react-icons/fi';
import { useNavigate } from 'react-router-dom';

const Marriage = ({admin,marriageData,userData}) => {
  var navigate = useNavigate();

  console.log("Printing the received Marriage DATA")
  console.log(marriageData);


  const nav = ()=> {
    navigate("/edit_other",{state:{type:"Marriage",marriageData:marriageData}});
  }

  const navToMarriage = () =>{
    navigate("/marriage_paper",{state:{userData:userData,marriageData:marriageData}})
  }

  return (
    <div> 
    <div className='rounded-md m-1 mt-5'>
    {admin ? <div className='float-right'>
        <button type='button' onClick={nav}  style={{ color:'#03C9D7',backgroundColor:'#E5FAFB'}} className="text-2xl opacity-0.9 p-4 hover:drop-shadow-xl rounded-lg">
          <FiEdit />
        </button>
        <p className=' m-1'>Edit</p>
        </div>: <></>}

          <h3 className=' font-bold text-xl mt-2'><span className=' font-extrabold text-2xl'>Date of Marriage: </span>{marriageData.dateOfMarriage}</h3>
          <h3 className=' text-xl font-semibold mt-2'> <span className='font-extrabold text-2xl'>spouse Name: </span>{marriageData.spouseName + " " + marriageData.spouseSurname}</h3>
          <h3 className=' text-xl font-semibold mt-2'> <span className='font-extrabold text-2xl'>spouse Surname: </span>{marriageData.spouseSurname}</h3>
          <h3 className=' text-xl font-semibold mt-2'> <span className=' font-extrabold text-2xl'>Place of Marriage: </span>{marriageData.marriagePlace}</h3>
        </div>
        <button type='button' onClick={navToMarriage}  style={{ color:'#03C9D7',backgroundColor:'#E5FAFB'}} className="text-2xl opacity-0.9 p-4 hover:drop-shadow-xl rounded-xl content-center">
          <FaCertificate />
          view certificate
        </button>
    </div>
  )
}

export default Marriage