import React from 'react'
import { FaCertificate } from 'react-icons/fa';
import { FiEdit } from 'react-icons/fi';
import { useNavigate } from 'react-router-dom';

const Baptism = ({userData,admin,baptismData}) => {
  var navigate = useNavigate();
  
console.log(" PRINTING THE RECEIVED BAPTISM DATA")
console.log(baptismData);

  const nav = () =>{

    // Sending the userdata to the form page
    navigate("/edit_other",{state:{type:"Baptism",baptismData:baptismData}})

  }
const navToCertificate = () =>{

  navigate("/certificate",{state:{userData:userData,baptismData:baptismData}});

}

  return (
    <div>
      {admin ? <div className='float-right'>
        <button type='button' onClick={nav}  style={{ color:'#03C9D7',backgroundColor:'#E5FAFB'}} className="text-2xl opacity-0.9 p-4 hover:drop-shadow-xl rounded-lg">
          <FiEdit />
        </button>
        <p className=' m-1'>Edit</p>
        </div> : <></>}
        

    <div className='rounded-md m-1 mt-5'>
          <h3 className=' font-bold text-xl mt-2'><span className=' font-extrabold text-2xl'>Date of Baptism: </span> {baptismData.dateOfBaptism}</h3>
          <h3 className=' text-xl font-semibold mt-2'> <span className=' font-extrabold text-2xl'>Place of Baptism: </span>{baptismData.placeOfBaptism}</h3>
        </div>
        <button type='button' onClick={navToCertificate}  style={{ color:'#03C9D7',backgroundColor:'#E5FAFB'}} className="text-2xl opacity-0.9 p-4 hover:drop-shadow-xl rounded-xl">
          <FaCertificate />
          view certificate
        </button>
    </div>
  )
}

export default Baptism