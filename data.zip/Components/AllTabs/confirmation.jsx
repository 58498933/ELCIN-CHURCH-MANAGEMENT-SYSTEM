import React from 'react'
import { FaCertificate } from 'react-icons/fa';
import { FiEdit } from 'react-icons/fi';
import { useNavigate } from 'react-router-dom';

const Confirmation = ({confirmationData,userData,admin}) => {

  console.log(" PRINTING THE RECEIVED CONFIRMATION DATA")
  console.log(confirmationData);
  var navigate = useNavigate()


  const nav = () => {
    navigate("/edit_other",{state:{type:"Confirmation",confirmationData:confirmationData}})
  }

  const navConfirm = () => {
    navigate("/confirmation_paper",{state:{userData:userData,confirmationData:confirmationData}})
  }

  return (
    <div>

<div className='rounded-md m-1 mt-5'>
  {admin ? <div className='float-right'>
        <button type='button' onClick={nav}  style={{ color:'#03C9D7',backgroundColor:'#E5FAFB'}} className="text-2xl opacity-0.9 p-4 hover:drop-shadow-xl rounded-lg">
        <FiEdit />
        </button>
        <p className=' m-1'>Edit</p>
        </div> : <></>}

          <h3 className=' font-bold text-xl mt-2'><span className=' font-extrabold text-2xl'>Date of confirmation: </span> {confirmationData.dateOfConfirmation}</h3>
          <h3 className=' text-xl font-semibold mt-2'> <span className=' font-extrabold text-2xl'>Place of confirmation: </span>{confirmationData.placeOfConfirmation}</h3>
        </div>
        <button type='button' onClick={navConfirm}  style={{ color:'#03C9D7',backgroundColor:'#E5FAFB'}} className="text-2xl opacity-0.9 p-4 hover:drop-shadow-xl rounded-xl">
          <FaCertificate />
          view certificate
        </button>

    </div>
  )
}

export default Confirmation