/* eslint-disable */
import React, { createContext, useContext, useState } from 'react';

const StateContext = createContext();

const initialState = {
  chat: false,
//   cart: false,
  userProfile: false,
  notification: false,
};

const registerAdmin = {
  surname:"", 
  name:"", 
  dob:"", 
  email: "", 
  password: "" ,
  cPassword:""
}
const memberPersonalDetails = {
  surname:"", 
  name:"", 
  dateOfBirth:"", 
  idNumber: "" ,
  placeOfBirth:"",
  birthPlace:""
}
const memberFatherDetails = {
  surname:"", 
  name:"", 
  dateOfBirth:"", 
  country:"",
  idNumber:"",
  birthPlace:""
}

const baptismMember = {
  surname:"", 
  name:"", 
  dob:"", 
  baptismPlace:""
}

const memberMotherDetails = {
  surname:"", 
  name:"", 
  dob:"", 
  country:"",
  idNumber: "" ,
  birthPlace:""
}

const spouseDetails = {
  surname:"", 
  name:"", 
  fatherName:"", 
  motheName: "", 
  address: "",
  telephone:"",
  sex:"",
  dob:"", 
  idNumber: "",

}

const churchMarriage = {
  churchName:"", 
  marriagePlace:"", 
  bishopName: "", 
  churchAddress: "",
  dateOfMarriage:"",
}

const initialValues = {};



export const ContextProvider = ({ children }) => {
  const [screenSize, setScreenSize] = useState(undefined);
  const [currentColor, setCurrentColor] = useState('#03C9D7');
  const [currentMode, setCurrentMode] = useState('Light');
  const [themeSettings, setThemeSettings] = useState(false);
  const [activeMenu, setActiveMenu] = useState(false);
  const [isClicked, setIsClicked] = useState(initialState);
  const [activeGraph, setActiveGraph] = useState(true);
  const [userAdmin,setAdmin] = useState(false);
  const [userMember,setMember] = useState(false);

  //state for handling the
  const [adminRegister,setAdminRegister] = useState(registerAdmin)

  const [memberDetails,setMemberDetails] = useState(memberPersonalDetails)
  const [membersFather,setMembersFather] = useState( memberFatherDetails)
  const [membersMother,setMembersMother] = useState(memberMotherDetails)
  // Baptism INput
  const [membersBaptism,setMembersbaptism] = useState(baptismMember)
  const [marriageSpouse,setMarriageSpouse] = useState(spouseDetails)
  const [churchDetails,setChurchDetails] = useState( churchMarriage)
 
  
  
 


  const setMode = (e) => {
    // passing in an event in the method
    setCurrentMode(e.target.value);
    localStorage.setItem('themeMode', e.target.value);
    // close the settings panel
    setThemeSettings(false);
  };

  const setColor = (color) => {
    setCurrentColor(color);
    localStorage.setItem('colorMode', color);
    // close the settings sidebar after you click on color
    setThemeSettings(false);
  };

  const handleClick = (clicked) => setIsClicked({ ...initialState, [clicked]: true });

  return (
    // eslint-disable-next-line react/jsx-no-constructed-context-values
    <StateContext.Provider value={{churchDetails,setChurchDetails,marriageSpouse,setMarriageSpouse,membersBaptism,setMembersbaptism,membersMother,setMembersMother,membersFather,setMembersFather,memberDetails,setMemberDetails,adminRegister,setAdminRegister,currentColor,userAdmin,setAdmin, setCurrentColor,userMember,setMember, setCurrentMode, currentMode,handleClick, isClicked,  setIsClicked,activeMenu, screenSize, setScreenSize, activeGraph, setActiveGraph, initialState,setActiveMenu, setMode, setColor, themeSettings, setThemeSettings }}>
      {children}
    </StateContext.Provider>
  );
};

export const useStateContext = () => useContext(StateContext);
